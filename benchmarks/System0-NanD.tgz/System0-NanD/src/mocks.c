#include "tsfi_merkle.h"
#include "tsfi_svdag.h"
#include "tsfi_wire_firmware.h"
#include "lau_telemetry.h"
#include "tsfi_zmm_vm.h"

// Memory Mocks (Minimal for demo)
void* lau_malloc_loc(size_t size, const char *file, int line) { (void)file; (void)line; return malloc(size); }
void* lau_memalign_loc(size_t alignment, size_t size, const char *file, int line) { 
    (void)file; (void)line;
    void *ptr;
    if (posix_memalign(&ptr, alignment, size) != 0) return NULL;
    return ptr;
}
void lau_free(void* ptr) { free(ptr); }
void lau_report_memory_metrics(void) {}
void lau_assert_zero_unsealed_leaks(const char *context, void *teardown_ptr) { (void)context; (void)teardown_ptr; }
void* lau_malloc_wired_loc(size_t size, const char *file, int line) { (void)file; (void)line; return malloc(size); }
void lau_seal_object_loc(void *ptr, const char *file, int line) { (void)ptr; (void)file; (void)line; }


// Registry Mocks
LauMetadata* lau_registry_find(void *payload) { (void)payload; return NULL; }
void lau_registry_teardown(void) {}

// SVDAG & Hilbert Mocks
float tsfi_svdag_execute(const TSFiHelmholtzSVDAG *dag) {
    (void)dag;
    return 0.0f;
}
void tsfi_hilbert_init_glyph(TSFiHilbertGlyph *g) { (void)g; }
void tsfi_hilbert_project_box(TSFiHilbertGlyph *g, float width, float height) { (void)g; (void)width; (void)height; }

// Time Mocks
unsigned long long get_time_ns(void) { return 0; }


// Mock for Wire Firmware
LauWireFirmware* tsfi_wire_firmware_get_no_init(void) {
    return NULL;
}
LauWireFirmware* tsfi_wire_firmware_get(void) {
    return NULL;
}
void tsfi_wire_firmware_load_waveform(LauWireFirmware *fw, int reg_idx, void *w) {
    (void)fw; (void)reg_idx; (void)w;
}

// Mock for Telemetry
LauTelemetryState* tsfi_telemetry_get(void) {
    return NULL;
}
void lau_telemetry_integrity_update(LauTelemetryState *state) {
    (void)state;
}
void lau_telemetry_report_event(LauTelemetryState *state, uint64_t ptr, uint64_t size, uint32_t type, uint32_t flags) {
    (void)state; (void)ptr; (void)size; (void)type; (void)flags;
}

// Mock for Audit
void lau_audit_init(void) {}
void lau_audit_record(void *ptr, size_t size, const char *context, int line) {
    (void)ptr; (void)size; (void)context; (void)line;
}

// Mock for Thunks
void thunk_check_bounds(ThunkProxy *p, size_t sz) { (void)p; (void)sz; }
void* ThunkProxy_emit_baked(ThunkProxy *p, void *fn, int arg_c, ...) {
    (void)p; (void)fn; (void)arg_c;
    return NULL;
}

void ThunkProxy_destroy_authoritative(ThunkProxy *p) { (void)p; }
ThunkProxy* ThunkProxy_create(void) { return NULL; }
void* ThunkProxy_emit_io_poll(ThunkProxy *p, int fd) { (void)p; (void)fd; return NULL; }
void ThunkProxy_seal(ThunkProxy *p) { (void)p; }

// Math Mocks
#include <math.h>
float tsfi_fabsf(float x) { return fabsf(x); }
float tsfi_sqrtf(float x) { return sqrtf(x); }

// Global atomic for initialization
_Atomic int g_init_in_progress = 0;
_Atomic int g_teardown_in_progress = 0;
