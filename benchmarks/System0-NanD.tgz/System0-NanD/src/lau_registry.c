#define _GNU_SOURCE
#include "lau_registry.h"
#include "lau_telemetry.h"
#include "tsfi_wire_firmware.h"
#include "tsfi_io.h"
#include <stdatomic.h>
#include <stddef.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <stdio.h>

#include <stdio.h>
#include <string.h>
#include <time.h>
#include <nmmintrin.h>
#include <immintrin.h>

LauMetadata *g_head = NULL;
_Atomic int g_lock = 0;
LauTelemetryState *g_telem = NULL;
LauRegistryManifold *g_local_manifold = NULL;

static void safe_ptr_update(LauMetadata **ptr_to_member, LauMetadata *val, LauMetadata *m_obj) {
    if (!m_obj) {
        *ptr_to_member = val;
        return;
    }
    // Check if memory is currently writable according to our tracking
    // If current_prot is 0, we assume it might be read-only if bit 55 is set, or just unprotect to be safe.
    bool sealed = (m_obj->alloc_size & (1ULL << 55)) != 0;
    bool needs_unlock = sealed || (m_obj->current_prot != 0 && !(m_obj->current_prot & PROT_WRITE));
    
    if (needs_unlock) {
        size_t pg = sysconf(_SC_PAGESIZE);
        uintptr_t addr = (uintptr_t)m_obj->actual_start & ~(pg - 1);
        // Unprotect 8KB to cover any possible header/metadata placement
        if (tsfi_mprotect((void*)addr, pg * 2, PROT_READ | PROT_WRITE) != 0) {
            fprintf(stderr, "[REGISTRY] safe_ptr_update: UNLOCK FAILED for %p (addr %p)\n", (void*)m_obj, (void*)addr);
        }
    }
    
    *ptr_to_member = val;
    
    if (needs_unlock) {
        size_t pg = sysconf(_SC_PAGESIZE);
        uintptr_t addr = (uintptr_t)m_obj->actual_start & ~(pg - 1);
        if (tsfi_mprotect((void*)addr, pg * 2, m_obj->current_prot ? m_obj->current_prot : PROT_READ) != 0) {
            fprintf(stderr, "[REGISTRY] safe_ptr_update: RE-LOCK FAILED for %p (addr %p)\n", (void*)m_obj, (void*)addr);
        }
    }
}

static inline void lau_spin_lock(_Atomic int *lock) {
    while (atomic_exchange_explicit(lock, 1, memory_order_acquire)) {
        __builtin_ia32_pause();
    }
}

static inline void lau_spin_unlock(_Atomic int *lock) {
    atomic_store_explicit(lock, 0, memory_order_release);
}

__attribute__((constructor(101)))
void lau_registry_init_manifold(void) {
    if (!g_local_manifold) {
        g_local_manifold = (LauRegistryManifold*)mmap(NULL, sizeof(LauRegistryManifold), PROT_READ|PROT_WRITE, MAP_PRIVATE|MAP_ANONYMOUS, -1, 0);
        if (g_local_manifold != MAP_FAILED) {
            memset(g_local_manifold, 0, sizeof(LauRegistryManifold));
        } else {
            g_local_manifold = NULL;
        }
    }
}

__attribute__((constructor(102)))
void lau_registry_init_telemetry(void) {
    lau_registry_init_manifold();
    const char *id = getenv("TSFI_TELEMETRY_ID");
    if (!id) return;
    
    char name[256];
    snprintf(name, sizeof(name), "/tsfi_telem_%s", id);
    int fd = tsfi_shm_open(name, O_RDWR | O_CREAT, 0666);
    if (fd == -1) {
        return;
    }
    if (ftruncate(fd, sizeof(LauTelemetryState)) == -1) { 
        close(fd); return; 
    }
    g_telem = mmap(NULL, sizeof(LauTelemetryState), PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    close(fd);
    if (g_telem == MAP_FAILED) { 
        g_telem = NULL; return; 
    }
}

static inline uint64_t get_time_ns_fast() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000000000ULL + ts.tv_nsec;
}

static void lau_telemetry_integrity_update(LauTelemetryState *s) {
    if (!s) return;
    atomic_fetch_add(&s->sequence_number, 1);
    uint64_t crc = 0;
    crc = _mm_crc32_u64(crc, s->magic);
    crc = _mm_crc32_u64(crc, s->pid);
    crc = _mm_crc32_u64(crc, atomic_load(&s->total_allocs));
    crc = _mm_crc32_u64(crc, atomic_load(&s->total_frees));
    crc = _mm_crc32_u64(crc, atomic_load(&s->active_allocs));
    crc = _mm_crc32_u64(crc, atomic_load(&s->active_bytes));
    crc = _mm_crc32_u64(crc, atomic_load(&s->peak_bytes));
    crc = _mm_crc32_u64(crc, atomic_load(&s->exec_steps));
    crc = _mm_crc32_u64(crc, atomic_load(&s->exec_last_ts));
    uint64_t *dir_ptr = (uint64_t*)s->last_directive_str;
    crc = _mm_crc32_u64(crc, *dir_ptr);
    crc = _mm_crc32_u64(crc, (uint64_t)atomic_load(&s->recip_symmetry));
    atomic_store(&s->header_crc, (uint32_t)crc);
}

static void report_event(uint64_t ptr, uint64_t size, uint32_t type, uint32_t flags) {
    if (!g_telem) return;
    if (type == 3) { 
        atomic_fetch_sub(&g_telem->active_allocs, 1);
        atomic_fetch_sub(&g_telem->active_bytes, size);
        atomic_fetch_add(&g_telem->total_frees, 1);
    } else { 
        atomic_fetch_add(&g_telem->total_allocs, 1);
        atomic_fetch_add(&g_telem->active_allocs, 1);
        uint64_t curr = atomic_fetch_add(&g_telem->active_bytes, size) + size;
        uint64_t peak = atomic_load(&g_telem->peak_bytes);
        while (curr > peak && !atomic_compare_exchange_weak(&g_telem->peak_bytes, &peak, curr));
    }
    uint32_t head = atomic_fetch_add(&g_telem->event_head, 1);
    uint32_t idx = head % LAU_TELEM_RING_SIZE;
    LauTelemetryEvent *e = &g_telem->events[idx];
    e->timestamp = get_time_ns_fast();
    e->ptr_addr = ptr;
    e->size = size;
    e->type = type;
    e->flags = flags;
    lau_telemetry_integrity_update(g_telem);
    
}

void lau_registry_report_event(uint64_t ptr, uint64_t size, uint32_t type, uint32_t flags) {
    report_event(ptr, size, type, flags);
}

static void manifold_insert(LauRegistryManifold *m, LauMetadata *md) {
    if (!m || !md) return;
    uint32_t count = atomic_load(&m->count);
    if (count < LAU_REGISTRY_CAPACITY) {
        LauMetadata *slot = &m->slots[count];
        // Deep Structural Copy
        slot->actual_start = md->actual_start;
        slot->payload_start = md->payload_start;
        slot->alloc_size = md->alloc_size;
        slot->alloc_file = md->alloc_file;
        slot->probe_latency = md->probe_latency;
        slot->physical_tier = md->physical_tier;
        slot->current_prot = md->current_prot;
        slot->instruction_hash = md->instruction_hash;
        slot->next = NULL; slot->prev = NULL; 
        
        // Critical: Search index MUST be the payload address
        m->search_index[count] = (uintptr_t)md->payload_start;
        atomic_fetch_add(&m->count, 1);
    } else {
        // Drop silently if over capacity
    }
}

static void manifold_remove(LauRegistryManifold *m, void *ptr) {
    if (!m || !ptr) return;
    uint32_t count = atomic_load(&m->count);
    uintptr_t target = (uintptr_t)ptr;
    for (uint32_t i = 0; i < count; i++) {
        if (m->search_index[i] == target) {
            uint32_t last = atomic_fetch_sub(&m->count, 1) - 1;
            if (i != last) {
                m->slots[i] = m->slots[last];
                m->search_index[i] = m->search_index[last];
            }
            break;
        }
    }
}

_Atomic int g_teardown_in_progress = 0;

void lau_registry_insert(LauMetadata *m) {
    if (!m) return;
    lau_registry_lock();
    
    extern _Atomic int g_init_in_progress;
    if (!atomic_load(&g_init_in_progress) && !atomic_load(&g_teardown_in_progress)) {
        // Safety check disabled during early boot or teardown to avoid infinite loops
    }

    // Reject duplicates to prevent circular lists
    LauMetadata *slow = g_head;
    LauMetadata *fast = g_head;
    while (slow) {
        if (slow == m) {
            lau_registry_unlock();
            return;
        }
        slow = slow->next;
        if (fast) fast = fast->next;
        if (fast) fast = fast->next;
        if (slow && slow == fast) {
            fprintf(stderr, "FATAL: lau_registry_insert detected circular list in duplicate check! Node: %p\n", (void*)slow);
            abort();
        }
    }

    m->next = g_head;
    m->prev = NULL;
    if (g_head) safe_ptr_update(&g_head->prev, m, g_head);
    g_head = m;

    LauWireFirmware *fw = tsfi_wire_firmware_get_no_init();
    if (fw) {
        // fprintf(stderr, "Inserting into firmware manifold: %p\n", m);
        manifold_insert(&fw->manifold, m);
    } else {
        if (!g_local_manifold) lau_registry_init_manifold();
        // fprintf(stderr, "Inserting into local manifold: %p\n", m);
        manifold_insert(g_local_manifold, m);
    }
    lau_registry_unlock();
    
    size_t size = m->alloc_size & 0x007FFFFFFFFFFFFFULL;
    uint32_t flags = (m->alloc_size & (1ULL << 55)) ? LAU_TELEM_FLAG_SEALED : 0;
    report_event((uint64_t)m->actual_start, size, (uint32_t)(m->alloc_size >> 56), flags);
}

void tsfi_registry_backfill_manifold(void) {
    LauWireFirmware *fw = tsfi_wire_firmware_get_no_init();
    if (!fw) return;
    
    static _Atomic int in_backfill = 0;
    if (atomic_exchange(&in_backfill, 1)) return;

    lau_registry_lock();
    LauMetadata *curr = g_head;
    int count = 0;
    while (curr) {
        manifold_insert(&fw->manifold, curr);
        curr = curr->next;
        if (++count > 10000) {
            break;
        }
    }
    if (g_local_manifold) atomic_store(&g_local_manifold->count, 0);
    lau_registry_unlock();
    atomic_store(&in_backfill, 0);
}

LauMetadata* lau_registry_find_locked(void *payload) {
    if (!payload) return NULL;
    
    LauWireFirmware *fw = tsfi_wire_firmware_get_no_init();
    if (fw) {
        LauMetadata *m = tsfi_registry_scan_zmm(&fw->manifold, payload);
        if (m && m->payload_start == payload) return m;
    }
    if (g_local_manifold) {
        LauMetadata *m = tsfi_registry_scan_zmm(g_local_manifold, payload);
        if (m && m->payload_start == payload) return m;
    }
    
    LauMetadata *curr = g_head;
    while (curr) {
        if (curr->payload_start == payload) return curr;
        curr = curr->next;
    }
    return NULL;
}

extern bool lau_registry_is_ptr_mapped(void *ptr);

void lau_registry_remove_locked(LauMetadata *m) {
    if (!m) return;

    // Physical Rigidity: verify neighbors point back to us before unlinking
    if (m->prev && lau_registry_is_ptr_mapped(m->prev) && m->prev->next != m) {
        fprintf(stderr, "[CRITICAL] Registry Corruption: m->prev->next (%p) != m (%p)\n", (void*)m->prev->next, (void*)m);
    }
    if (m->next && lau_registry_is_ptr_mapped(m->next) && m->next->prev != m) {
        fprintf(stderr, "[CRITICAL] Registry Corruption: m->next->prev (%p) != m (%p)\n", (void*)m->next->prev, (void*)m);
    }

    if (m->prev || m->next || g_head == m) {
        if (m->prev && lau_registry_is_ptr_mapped(m->prev)) safe_ptr_update(&m->prev->next, m->next, m->prev);
        if (g_head == m) g_head = m->next;
        if (m->next && lau_registry_is_ptr_mapped(m->next)) safe_ptr_update(&m->next->prev, m->prev, m->next);
    }
    
    // Clear our own pointers to prevent dangling links or double-removals
    safe_ptr_update(&m->next, NULL, m);
    safe_ptr_update(&m->prev, NULL, m);

    // Zero from all manifolds
    manifold_remove(g_local_manifold, m->payload_start);
    LauWireFirmware *fw = tsfi_wire_firmware_get_no_init();
    if (fw) {
        extern LauMetadata* lau_registry_find_locked(void*);
        LauMetadata *fm = lau_registry_find_locked(fw);
        bool fw_sealed = fm && (fm->alloc_size & (1ULL << 55));
        if (fw_sealed) {
            lau_mprotect_meta(fm, PROT_READ | PROT_WRITE);
        }
        manifold_remove(&fw->manifold, m->payload_start);
        if (fw_sealed) {
            lau_mprotect_meta(fm, fm->current_prot);
        }
    }
}

void lau_registry_remove(LauMetadata *m) {
    if (!m) return;
    
    lau_registry_lock();
    
    LauMetadata *real_m = NULL;
    // Safety check: ensure m is actually in the list using cycle-safe traversal
    LauMetadata *slow = g_head;
    LauMetadata *fast = g_head;
    while (slow) {
        if (slow->actual_start == m->actual_start) { real_m = slow; break; }
        slow = slow->next;
        if (fast) fast = fast->next;
        if (fast) fast = fast->next;
        if (slow && slow == fast) {
            fprintf(stderr, "FATAL: lau_registry_remove detected circular list! Node: %p\n", (void*)slow);
            abort();
        }
    }

    if (real_m) {
        lau_registry_remove_locked(real_m);
    }
    lau_registry_unlock();
    
    if (real_m) {
        size_t size = m->alloc_size & 0x007FFFFFFFFFFFFFULL;
        uint32_t flags = (m->alloc_size & (1ULL << 55)) ? LAU_TELEM_FLAG_SEALED : 0;
        report_event((uint64_t)m->actual_start, size, 3, flags);
    }
}

#include <sys/mman.h>
#include <unistd.h>

static int g_safe_check_pipe[2] = {-1, -1};

bool lau_registry_is_ptr_mapped(void *ptr) {
    if (!ptr) return false;
    
    // Lazy init pipe for safe checks
    if (g_safe_check_pipe[0] == -1) {
        if (pipe(g_safe_check_pipe) != 0) return true; // Fallback to unsafe if pipe fails
    }

    // Try to write 1 byte from the pointer to the pipe. 
    // If it's invalid memory, it will return -1 with EFAULT instead of crashing.
    if (write(g_safe_check_pipe[1], ptr, 1) < 0) {
        return false;
    }
    
    // Clean up the pipe
    char dummy;
    if (read(g_safe_check_pipe[0], &dummy, 1) < 0) {
        // Silently ignore pipe read errors
    }
    return true;
}

LauMetadata* lau_registry_find(void *payload) {
    if (!payload) return NULL;
    
    // Explicitly bypass firmware-accelerated manifold during early boot or teardown
    extern _Atomic int g_teardown_in_progress;
    extern _Atomic int g_init_in_progress;
    int in_cleanup = atomic_load(&g_init_in_progress) || atomic_load(&g_teardown_in_progress);
    
    if (in_cleanup) {
        lau_registry_lock();
        LauMetadata *slow = g_head;
        LauMetadata *fast = g_head;
        while (slow && lau_registry_is_ptr_mapped(slow)) {
            if (slow->payload_start == payload) { lau_registry_unlock(); return slow; }
            slow = slow->next;
            if (fast && lau_registry_is_ptr_mapped(fast)) fast = fast->next;
            if (fast && lau_registry_is_ptr_mapped(fast)) fast = fast->next;
            if (slow && slow == fast) {
                fprintf(stderr, "FATAL: lau_registry_find detected circular list in bypass loop! Node: %p\n", (void*)slow);
                abort();
            }
        }
        lau_registry_unlock();
        return NULL;
    }

    LauMetadata *manifold_m = NULL;
    LauWireFirmware *fw = tsfi_wire_firmware_get_no_init();
    if (fw && lau_registry_is_ptr_mapped(fw)) {
        manifold_m = tsfi_registry_scan_zmm(&fw->manifold, payload);
    }
    if (!manifold_m && g_local_manifold && lau_registry_is_ptr_mapped(g_local_manifold)) {
        manifold_m = tsfi_registry_scan_zmm(g_local_manifold, payload);
    }
    
    lau_registry_lock();
    LauMetadata *slow = g_head;
    LauMetadata *fast = g_head;
    while (slow && lau_registry_is_ptr_mapped(slow)) {
        if (manifold_m && slow->actual_start == manifold_m->actual_start) {
            lau_registry_unlock();
            return slow;
        }
        if (slow->payload_start == payload) { lau_registry_unlock(); return slow; }
        
        LauMetadata *next_slow = slow->next;
        if (getenv("TSFI_DEBUG_REGISTRY")) { printf("[DEBUG] find slow=%p payload_start=%p\n", (void*)slow, (void*)slow->payload_start); fflush(stdout); }
        slow = next_slow;
        
        if (fast && lau_registry_is_ptr_mapped(fast)) {
            fast = fast->next;
            if (fast && lau_registry_is_ptr_mapped(fast)) fast = fast->next;
        }
        if (slow && slow == fast) {
            fprintf(stderr, "FATAL: lau_registry_find detected circular list in g_head! Node: %p\n", (void*)slow);
            abort();
        }
    }
    
    // Range check fallback
    slow = g_head;
    fast = g_head;
    while (slow && lau_registry_is_ptr_mapped(slow)) {
        size_t size = slow->alloc_size & 0x007FFFFFFFFFFFFFULL;
        uintptr_t start = (uintptr_t)slow->payload_start;
        uintptr_t p = (uintptr_t)payload;
        if (p >= start && p < start + size) { lau_registry_unlock(); return slow; }
        
        slow = slow->next;
        if (fast && lau_registry_is_ptr_mapped(fast)) fast = fast->next;
        if (fast && lau_registry_is_ptr_mapped(fast)) fast = fast->next;
        if (slow && slow == fast) {
            fprintf(stderr, "FATAL: lau_registry_find detected circular list in range check! Node: %p\n", (void*)slow);
            abort();
        }
    }
    lau_registry_unlock();
    return NULL;
}

LauMetadata* lau_registry_get_head(void) {
    return g_head;
}


uint32_t lau_registry_get_count(void) {
    LauWireFirmware *fw = tsfi_wire_firmware_get_no_init();
    if (fw) return atomic_load(&fw->manifold.count); 
    if (g_local_manifold) return atomic_load(&g_local_manifold->count);
    return 0;
}

void lau_telemetry_record_exec(const char *directive) {
    if (!g_telem) return;
    atomic_fetch_add(&g_telem->exec_steps, 1);
    struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
    uint64_t now = (uint64_t)ts.tv_sec * 1000000000ULL + ts.tv_nsec;
    atomic_store(&g_telem->exec_last_ts, now);
    if (directive) {
        char *dest = (char*)g_telem->last_directive_str;
        size_t i;
        for (i = 0; i < 63 && directive[i] != '\0'; i++) dest[i] = directive[i];
        dest[i] = '\0';
    }
    lau_telemetry_integrity_update(g_telem);
}

static _Atomic long g_lock_owner = 0;
static _Atomic int g_lock_depth = 0;

void lau_registry_lock(void) {
    long tid = (long)syscall(SYS_gettid);
    if (atomic_load(&g_lock_owner) == tid) {
        atomic_fetch_add(&g_lock_depth, 1);
        return;
    }
    extern void lau_spin_lock(_Atomic int *lock);
    lau_spin_lock(&g_lock);
    atomic_store(&g_lock_owner, tid);
    atomic_store(&g_lock_depth, 1);
}

void lau_registry_unlock(void) {
    long tid = (long)syscall(SYS_gettid);
    if (atomic_load(&g_lock_owner) != tid) return;
    if (atomic_fetch_sub(&g_lock_depth, 1) > 1) return;
    
    atomic_store(&g_lock_owner, 0);
    extern void lau_spin_unlock(_Atomic int *lock);
    lau_spin_unlock(&g_lock);
}
LauTelemetryState* lau_telemetry_get_state(void) { 
    return g_telem; 
}

LauMetadata* tsfi_registry_scan_zmm(LauRegistryManifold *m, void *ptr) {
    if (!m || !ptr) return NULL;
    uint32_t count = atomic_load(&m->count);
    if (count == 0 || count > LAU_REGISTRY_CAPACITY) return NULL;
    uintptr_t target = (uintptr_t)ptr;
    __m512i v_target = _mm512_set1_epi64(target);
    uint32_t i = 0;
    for (; i + 7 < count && i + 7 < LAU_REGISTRY_CAPACITY; i += 8) {
        __m512i v_index = _mm512_loadu_si512(&m->search_index[i]);
        __mmask8 mask = _mm512_cmpeq_epu64_mask(v_index, v_target);
        if (mask) return &m->slots[i + __builtin_ctz(mask)];
    }
    for (uint32_t j = i; j < count && j < LAU_REGISTRY_CAPACITY; j++) {
        uintptr_t start = m->search_index[j];
        size_t size = m->slots[j].alloc_size & 0x007FFFFFFFFFFFFFULL;
        if (target >= start && target < start + size) return &m->slots[j];
    }
    return NULL;
}

void lau_registry_teardown(void) {
    if (g_local_manifold) {
        lau_registry_lock();
        LauMetadata *curr = g_head;
        LauMetadata *m = NULL;
        while (curr) {
            if (curr->actual_start == (void*)g_local_manifold) { m = curr; break; }
            curr = curr->next;
        }
        if (m) {
            if (m->prev) safe_ptr_update(&m->prev->next, m->next, m->prev);
            else g_head = m->next;
            if (m->next) safe_ptr_update(&m->next->prev, m->prev, m->next);
            munmap(m->actual_start, m->alloc_size & 0x007FFFFFFFFFFFFFULL);
        }
        lau_registry_unlock();
        g_local_manifold = NULL;
    }
}
