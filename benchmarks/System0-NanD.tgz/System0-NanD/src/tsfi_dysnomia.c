#include "tsfi_dysnomia.h"
#include "tsfi_io.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "tsfi_pool.h"

struct Fa* allocFa(void) { return tsfi_pool_acquire_fa(); }
struct SHA* allocSHA(void) { return tsfi_pool_acquire_sha(); }
struct SHAO* allocSHAO(void) { return tsfi_pool_acquire_shao(); }
struct SHIO* allocSHIO(void) { return tsfi_pool_acquire_shio(); }
struct YI* allocYI(void) { return tsfi_pool_acquire_yi(); }
struct Dai* allocDai(void) { return tsfi_pool_acquire_dai(); }
struct ZHENG* allocZHENG(void) { return tsfi_pool_acquire_zheng(); }
struct ZHOU* allocZHOU(void) { return tsfi_pool_acquire_zhou(); }
struct YANG* allocYANG(void) { return tsfi_pool_acquire_yang(); }

void freeFa(struct Fa* F) {
    if (!F) return;
    tsfi_bn_free(F->Base);
    tsfi_bn_free(F->Secret);
    tsfi_bn_free(F->Signal);
    tsfi_bn_free(F->Channel);
    tsfi_bn_free(F->Contour);
    tsfi_bn_free(F->Pole);
    tsfi_bn_free(F->Identity);
    tsfi_bn_free(F->Foundation);
    tsfi_bn_free(F->Element);
    tsfi_bn_free(F->Coordinate);
    tsfi_bn_free(F->Charge);
    tsfi_bn_free(F->Limit);
    tsfi_bn_free(F->Monopole);
    tsfi_pool_release_fa(F);
}

void freeSHA(struct SHA* F) {
    if (!F) return;
    freeFa(F->Mu);
    tsfi_bn_free(F->Dynamo);
    tsfi_pool_release_sha(F);
}

void freeSHAO(struct SHAO* F) {
    if (!F) return;
    freeSHA(F->Rod);
    freeSHA(F->Cone);
    tsfi_bn_free(F->Barn);
    tsfi_pool_release_shao(F);
}

void freeSHIO(struct SHIO* F) {
    if (!F) return;
    freeSHAO(F->Rho);
    tsfi_bn_free(F->Manifold);
    tsfi_bn_free(F->Monopole);
    tsfi_pool_release_shio(F);
}

void freeYI(struct YI* F) {
    if (!F) return;
    freeSHIO(F->Psi);
    tsfi_bn_free(F->Xi);
    tsfi_bn_free(F->Ring);
    tsfi_pool_release_yi(F);
}

void freeDAI(struct Dai* D) {
    if (!D) return;
    tsfi_bn_free(D->Ichidai);
    tsfi_bn_free(D->Daiichi);
    tsfi_pool_release_dai(D);
}

void freeZHENG(struct ZHENG* Z) {
    if (!Z) return;
    if (Z->d) freeZHENG(Z->d);
    if (Z->n) freeZHENG(Z->n);
    tsfi_pool_release_zheng(Z);
}

void freeZHOU(struct ZHOU* Z) {
    if (!Z) return;
    freeZHENG(Z->Lambda);
    lau_free(Z->Process);
    if (Z->n) freeZHOU(Z->n);
    tsfi_pool_release_zhou(Z);
}

void freeYANG(struct YANG* F) {
    if (!F) return;
    freeYI(F->Eta);
    tsfi_bn_free(F->Ring);
    freeDAI(F->Iota);
    freeZHOU(F->Phi);
    tsfi_pool_release_yang(F);
}




static void print_bn_field(const char* label, TSFiBigInt* bn) {
    if (bn) {
        tsfi_io_printf(stderr, "  %s: 0x", label);
        if (bn->active_limbs == 0) {
            tsfi_io_printf(stderr, "0");
        } else {
            for (int i = (int)bn->active_limbs - 1; i >= 0; i--) {
                tsfi_io_printf(stderr, "%013lx", bn->limbs[i]);
            }
        }
        tsfi_io_printf(stderr, "\n");
    } else {
        tsfi_io_printf(stderr, "  %s: NULL\n", label);
    }
}

void printFa(struct Fa* Mu) {
    if (!Mu) return;
    print_bn_field("Base", Mu->Base);
    print_bn_field("Secret", Mu->Secret);
    print_bn_field("Signal", Mu->Signal);
    print_bn_field("Channel", Mu->Channel);
    print_bn_field("Contour", Mu->Contour);
    print_bn_field("Pole", Mu->Pole);
    print_bn_field("Identity", Mu->Identity);
    print_bn_field("Foundation", Mu->Foundation);
    print_bn_field("Element", Mu->Element);
    print_bn_field("Coordinate", Mu->Coordinate);
    print_bn_field("Charge", Mu->Charge);
    print_bn_field("Limit", Mu->Limit);
    print_bn_field("Monopole", Mu->Monopole);
}

void printSHIO(struct SHIO* Fe) {
    if (!Fe) return;
    tsfi_io_printf(stderr, "Rod:\n");
    if (Fe->Rho && Fe->Rho->Rod) {
        printFa(Fe->Rho->Rod->Mu);
        print_bn_field("Dynamo", Fe->Rho->Rod->Dynamo);
    }
    tsfi_io_printf(stderr, "Cone:\n");
    if (Fe->Rho && Fe->Rho->Cone) {
        printFa(Fe->Rho->Cone->Mu);
        print_bn_field("Dynamo", Fe->Rho->Cone->Dynamo);
    }
    if (Fe->Rho) print_bn_field("Barn", Fe->Rho->Barn);
    print_bn_field("Manifold", Fe->Manifold);
    print_bn_field("Monopole", Fe->Monopole);
}

void printYI(struct YI* Yo) {
    if (!Yo) return;
    tsfi_io_printf(stderr, "printYI enter\n");
    print_bn_field("Xi", Yo->Xi);
    print_bn_field("Ring", Yo->Ring);
    printSHIO(Yo->Psi);
}

void printZHENG(struct ZHENG* Zuo) {
    // Basic traversal for debug
    struct ZHENG* Z = Zuo;
    while(Z != NULL) {    
        tsfi_io_printf(stderr, "Alpha: %p\n", Z->Alpha);
        Z = Z->n;
    }
}

void printZHOU(struct ZHOU* Zhuo) {
    if (!Zhuo) return;
}

void printYANG(struct YANG* Fan) {
    if (!Fan) return;
    tsfi_io_printf(stderr, "Phi:\n");
    printZHOU(Fan->Phi);
    tsfi_io_printf(stderr, "Eta:\n");
    printYI(Fan->Eta);
    print_bn_field("Ring", Fan->Ring);
    if (Fan->Iota) {
        print_bn_field("Omicron", Fan->Iota->Ichidai);
        print_bn_field("Omega", Fan->Iota->Daiichi);
    } else {
        tsfi_io_printf(stderr, "Iota: NULL\n");
    }
}

void tsfi_dysnomia_drain_pools(void) {
    tsfi_pool_teardown();
}
