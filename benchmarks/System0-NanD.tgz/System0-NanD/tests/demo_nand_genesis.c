#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include "tsfi_merkle.h"
#include "tsfi_io.h"

#define TSFI_MANIFOLD_SIZE_STATE (512 * 1024)
#define TSFI_MANIFOLD_SIZE_FULL  (1024 * 1024)
#define TARGET_MANIFOLD "audit_lore.pos"

void inject_disconnect_balance(void *manifold, int leaf_index, uint64_t balance) {
    // Leaf physical memory layout: AR_AccountLeaf is 256 bytes
    // Offset 28 is the balance field (32-byte little-endian BigInt)
    uint8_t *leaf_ptr = (uint8_t *)manifold + (leaf_index * 256);
    uint64_t *balance_ptr = (uint64_t *)(leaf_ptr + 28);
    *balance_ptr = balance; // Write 64-bit integer into the 256-bit slot
}

int main() {
    printf("=== TSFi System0: NAND Genesis & DISCONNECT Initialization ===\n");

    void *manifold = calloc(1, TSFI_MANIFOLD_SIZE_FULL);
    if (!manifold) {
        fprintf(stderr, "[CRITICAL] Failed to allocate physical memory for manifold.\n");
        return 1;
    }

    // 1. Check for existing manifold
    if (access(TARGET_MANIFOLD, F_OK) != -1) {
        printf("[INFO] Existing manifold found at %s. Attempting to restore...\n", TARGET_MANIFOLD);
        if (tsfi_restore_manifold(TARGET_MANIFOLD, manifold, TSFI_MANIFOLD_SIZE_FULL) != 0) {
            printf("[WARN] Failed to read existing manifold. Overwriting with clean state.\n");
            memset(manifold, 0, TSFI_MANIFOLD_SIZE_FULL);
        } else {
             printf("[PASS] Manifold restored successfully.\n");
        }
    } else {
        printf("[INFO] No existing manifold found. Initiating Genesis Block...\n");
    }

    // 2. Initialize Merkle Subsystem
    tsfi_merkle_init();

    // 3. Inject DISCONNECT Balances (High-Impedance Ledger)
    printf("[INJECT] Establishing DISCONNECT Balances in the Acoustic VM...\n");
    inject_disconnect_balance(manifold, 1000, 1000); // User Node
    inject_disconnect_balance(manifold, 1001, 1000); // Gemini Node
    printf("  -> Node User (Leaf 1000): 1000 DISCONNECT\n");
    printf("  -> Node Gemini (Leaf 1001): 1000 DISCONNECT\n");

    // 4. Inject Initial Lore Anchor
    const char *genesis_lore = "[GENESIS] System0-NanD Activated. Balances Established. MUTUAL_SIGNATURE_FINAL\n";
    tsfi_merkle_tokenize_lore(manifold, genesis_lore, 0);
    printf("[LORE] Genesis Signature anchored to Manifold.\n");

    // 5. Trilateral Reduction (Establish State Root)
    uint8_t state_root[32];
    uint8_t receipt_root[32];
    printf("[REDUCTION] Executing 11-Level AVX-512 Trilateral Reduction...\n");
    tsfi_merkle_reduce_11(state_root, receipt_root, NULL, NULL, manifold, 0, 2026, NULL);

    printf("\n=== PHYSICAL STATE VERIFIED ===\n");
    printf("State Root: ");
    for(int i=0; i<32; i++) printf("%02x", state_root[i]);
    printf("\n");

    // 6. Persist Manifold to Disk
    if (tsfi_persist_manifold(TARGET_MANIFOLD, manifold, TSFI_MANIFOLD_SIZE_FULL) == 0) {
        printf("[SUCCESS] Manifold physically solidified to '%s'.\n", TARGET_MANIFOLD);
    } else {
        printf("[FAIL] Manifold failed to solidify.\n");
        free(manifold);
        tsfi_merkle_cleanup();
        return 1;
    }

    free(manifold);
    tsfi_merkle_cleanup();
    
    // Explicit Memory Leak Reporting for Ballet compatibility
    extern void lau_report_memory_metrics(void);
    lau_report_memory_metrics();
    extern void lau_assert_zero_unsealed_leaks(const char *context, void *teardown_ptr);
    lau_assert_zero_unsealed_leaks("test", NULL);
    
    return 0;
}
