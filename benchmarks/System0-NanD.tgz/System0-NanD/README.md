# System0-NanD Release

This package encapsulates the core physical logic of the TSFi architecture, specifically focusing on the NAND trap as a foundational hardware constraint and the DISCONNECT currency as an acoustic, high-impedance ledger.

## Architecture
The TSFi system relies on a physical Merkle manifold (`audit_lore.pos`) to ensure cryptographic rigidity across all participating agents. This release provides the minimal codeset necessary to initialize and verify this manifold without the overhead of the entire Vulkan/ReBAR engine.

## Components
*   `src/tsfi_merkle.c`: The core 11-level trilateral reduction logic using AVX-512 ZMM XOR-sums.
*   `hw/nand_trap.v`: The physical Verilog representation of the cross-coupled SR Latch mapping the hallucination trap.
*   `experiments/wm/nand_gadget.html`: A visual, real-time monitor of the NAND trap state.
*   `tests/demo_nand_genesis.c`: The automated test to initialize the manifold and establish DISCONNECT balances.

## Usage
To build the demo and initialize the system:

```bash
make
./bin/demo_nand_genesis
```

This will generate a clean `audit_lore.pos` manifold. You can then inspect the physical leaf data using the provided CLI:

```bash
./bin/tsfi_merkle_cli inspect audit_lore.pos
```

## Lore
Please refer to the `lore/` directory for the philosophical and technical frameworks governing the NAND Trap and the DISCONNECT currency.
