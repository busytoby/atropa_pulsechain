#ifndef TSFI_ZMM_VM_H
#define TSFI_ZMM_VM_H

// --- Opcodes for Pipelined Execution ---
enum {
    ZMM_OP_END = 0,
    ZMM_OP_WLOAD,   // [OP, REG, FLOAT_VAL]
    ZMM_OP_WADD,    // [OP, DEST, SRC1, SRC2]
    ZMM_OP_WMUL,    // [OP, DEST, SRC1, SRC2]
    ZMM_OP_WSTORE,  // [OP, SRC, IDX]
    ZMM_OP_WDUMP,   // [OP, REG]
    // --- Hardware Thunk ABI ---
    VM_OP_SEAL,     // [OP, PTR_HI, PTR_LO]
    VM_OP_UNSEAL,   // [OP, PTR_HI, PTR_LO]
    VM_OP_INVOKE    // [OP, PTR_HI, PTR_LO, OFFSET]
};


#include "tsfi_wave512.h"
#include "tsfi_opt_zmm.h"
#include "lau_telemetry.h"
#include "tsfi_reaction.h"

#define TSFI_ZMM_REG_COUNT 16

typedef struct {
    wave512 registers[TSFI_ZMM_REG_COUNT];
    char output_buffer[4096];
    int output_pos;
    
    // Neurology Integration
    TsfiZmmManifest *manifest; // Managed by VM (allocated/freed)
    
    // Telemetry Integration
    LauTelemetryState *telem;  // Attached Shared Memory
    
    // Async LLM Transaction State
    uint64_t llm_tx_counter;
    int llm_tx_status[16];          // 0=Empty, 1=Pending, 2=Done
    char llm_tx_results[16][4096];  // Buffered outputs for receipts

    // Acoustic Proof of State Linkage
    uint8_t  last_state_root[32];   // The anchored Merkle root
    float    p_trilateral[3];       // [User, DeepSeek, Gemini]
    uint64_t dirac_count;           // Identified singularities
    
    // Helmholtz Reaction: The Perfect 9-Step Communication Standard
    TSFiHelmholtzAdductState adduct;
    int trilateral_epoch;           // Current Epoch (0-8)
    
    // Autonomous Neurology: 144 Transform Tracking
    uint8_t  individual_confirmations[18]; // 144 bits (18 * 8)
    float    reciprocity_errors[144];      // Measured delta per granule
} TsfiZmmVmState;

void tsfi_zmm_vm_init(TsfiZmmVmState *state);
void tsfi_zmm_vm_destroy(TsfiZmmVmState *state); 
void tsfi_zmm_vm_update_acoustic_state(TsfiZmmVmState *state, const uint8_t *root, float p1, float p2, float p3, uint64_t dirac_count);
void tsfi_zmm_vm_exec(TsfiZmmVmState *state, const char *code);

// Instruction Pipelining (Fused Execution)
void* tsfi_zmm_vm_compile_block(const char *code);
size_t tsfi_zmm_vm_compile_block_buffer(const char *code, void *buffer, size_t max_len);
void tsfi_zmm_vm_exec_block(TsfiZmmVmState *state, void *block);
void tsfi_zmm_vm_free_block(void *block);

// Binary Crossover (Zero-Parse Evolution)
// Splices blockA and blockB into child_buf.
size_t tsfi_zmm_vm_splice_block(const void *blockA, const void *blockB, void *child_buf, size_t max_len);

// Attach to telemetry if available
void tsfi_zmm_vm_attach_telemetry(TsfiZmmVmState *state, const char *id);

#endif // TSFI_ZMM_VM_H
