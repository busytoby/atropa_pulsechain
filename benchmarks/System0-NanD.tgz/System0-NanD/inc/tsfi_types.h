#ifndef TSFI_TYPES_H
#define TSFI_TYPES_H

#include <stddef.h>


// ---------------------------------------------------------
// Hypervisor Struct Prototype
// ---------------------------------------------------------
typedef struct {
    int id;
    int state;
    void (*fire_action)(void *ctx);
    void (*cycle_state)(void *ctx);
} HypervisorTestNode;


// 1. Meta-Thunk Dynamic Schema Definitions
typedef enum {
    THUNK_BAKED,
    THUNK_FORWARDING,
    THUNK_ZMM,
    THUNK_IOCTL
} ThunkInjectionType;

typedef struct {
    size_t offset;
    ThunkInjectionType type;
    int arity;
    void* target_fn;
} ThunkSignature;



#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <sys/types.h>
#include <stdatomic.h>

#define TSFI_VERSION "2.0.0"

#define LAU_TELEMETRY_MAGIC 0xCAFEBABE12345678
#define LAU_TELEM_FLAG_SEALED (1u << 0)
#define LAU_TELEM_RING_SIZE 1024

// --- Registry Database Definitions ---
#define LAU_REGISTRY_CAPACITY 65536

typedef struct {
    uint64_t timestamp;
    uint64_t ptr_addr;
    uint64_t size;
    uint32_t type;
    uint32_t flags;
} LauTelemetryEvent;

#define LAU_SEAL_NONE 0xFF

typedef struct LauMetadata {
    struct LauMetadata *next;
    struct LauMetadata *prev;
    const char *alloc_file;
    size_t alloc_size;
    void *actual_start;
    void *payload_start;
    uint32_t instruction_hash;
    uint32_t probe_latency;
    uint8_t current_prot;
    uint8_t physical_tier;
    uint8_t seal_level;
    uint8_t _pad[5]; // Pad 59 to 64
} LauMetadata;

typedef struct {
    // Aligned index for AVX-512 parallel search
    uint64_t search_index[LAU_REGISTRY_CAPACITY] __attribute__((aligned(64)));
    LauMetadata slots[LAU_REGISTRY_CAPACITY];
    _Atomic uint32_t count;
    uint8_t _alignment_guard[508]; // Pad to 512-byte boundary
} LauRegistryManifold;

// --- TSFi System Primitives ---

struct Dai;

typedef struct {
    uint32_t magic;
    _Atomic uint32_t sequence_number;
    uint32_t pid;
    _Atomic uint32_t header_crc;
    _Atomic uint32_t system_integrity_fault;
    
    _Atomic uint64_t total_allocs;
    _Atomic uint64_t total_frees;
    _Atomic uint64_t active_allocs;
    _Atomic uint64_t active_bytes;
    _Atomic uint64_t peak_bytes;
    
    _Atomic uint64_t exec_steps;
    _Atomic uint64_t exec_last_ts;
    char last_directive_str[256];

    LauTelemetryEvent events[LAU_TELEM_RING_SIZE];
    _Atomic uint32_t event_head;

    // GUI/Input Tracking
    struct {
        uint64_t last_shutter_ts;
        float shutter_fps;
        float velocity_flux;
        float jerk_metric;
        float surface_quality;
        uint64_t surface_hash;
    } mouse_scope;

    float current_intensity;
    char request_cmd[4096];
    
    struct Dai *recip_dai;
    float recip_symmetry;

    volatile char zmm_msg[8192];
    volatile uint64_t zmm_val;

    // --- TSFi Fourier TARE: The Orthogonal Metric Basis ---
    struct {
        double   weights[18][8]; // 144 Hilbert Mode Weights
        uint64_t tare_id;
        uint64_t epoch_lock;
        float    magnetic_offset;
    } active_tare;
} LauTelemetryState;
#define MAPPED_COMMON_FIELDS \
    int * const version; \
    char ** const resonance_as_status; \
    int * const counter; \
    void (*step_safety_epoch)(void); \
    void (*step_safety_state)(void); \
    void (*step_executor_directive)(char*); \
    void (*scramble)(void); \
    void (*provenance)(void); \
    void (*hilbert_eval)(float, float, float*); \
    void (*hilbert_batch)(void*, const float*, float*, int);

typedef struct MappedCommon {
    MAPPED_COMMON_FIELDS
} MappedCommon;

#define DEFINE_MAPPED_STRUCT(name, ...) \
    typedef struct { \
        struct { \
            MAPPED_COMMON_FIELDS \
        }; \
        __VA_ARGS__ \
    } name; \
    extern const ThunkSignature name##_schema[]; \
    extern const int name##_schema_count;

DEFINE_MAPPED_STRUCT(WaveSystem,
    int system_id;
    char *current_directive;
    double current_intensity;
    char *provenance_sig;
    
    // Extensibility
    void *fw;
    void *active_sessions[4];
    void *active_hilbert_glyph;
    char shared_pty_buffer[4096];
)

DEFINE_MAPPED_STRUCT(WavefrontContext,
    // Data Pointers (Host Memory)
    float *input_x;
    float *input_y;
    float *input_z;
    float *output_data;

    // Offsets into LauRegisterBank::vgpr for input/output data (Feynman points)
    int input_x_vgpr_offset;
    int input_y_vgpr_offset;
    int input_z_vgpr_offset; // Optional Z for 3D
    int output_vgpr_offset;

    int input_x_vgpr_secret;
    int input_y_vgpr_secret;
    int input_z_vgpr_secret;
    int output_vgpr_secret;

    // Batch metadata
    size_t batch_size; // Number of elements in the batch
    
    // VGPR-specific operations (Thunked)
    void (*load_x_to_vgpr)(void);
    void (*load_y_to_vgpr)(void);
    void (*load_z_to_vgpr)(void);
    void (*store_output_from_vgpr)(void);
    void (*execute_vgpr_kernel)(void); // Mathematical Core
    )

    // --- Creative Assets ---

    DEFINE_MAPPED_STRUCT(TeddyBear,
    float norm_density;
    float fur_roughness;
    float eye_intensity;
    float spectral_shift; // Used for "Blue" secret injection

    void *voxel_data;
    size_t voxel_count;

    // Physical state links
    void *heart_pulse_manifold;
    void *limb_thunks[4];
    )

    #endif // TSFI_TYPES_H