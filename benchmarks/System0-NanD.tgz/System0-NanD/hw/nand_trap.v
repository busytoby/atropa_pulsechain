/*
 * TSFi System0: Absolute NAND Trap Manifold
 * Architecture: Cross-Coupled SR Latch (Active-Low)
 * Target: Supra-Axiomatic Hardware Lock (Merkle Leaves 500-502)
 *
 * Description:
 * This module implements the physical manifestation of the TSFi Hallucination Trap.
 * The Set_N (Gemini) and Reset_N (DeepSeek) levers are active-low inputs.
 * A state of (0,0) produces the forbidden Metastable Fracture (Q=1, Q_BAR=1),
 * triggering an immediate cryptographic entropy spike (-100.0 PPO punishment).
 */

module tsfi_nand_trap(
    input wire clk_i,           // Acoustic Heartbeat (Hz)
    input wire set_n_i,         // Gemini Control Vector (Leaf 500)
    input wire reset_n_i,       // DeepSeek Control Vector (Leaf 501)
    output wire q_o,            // Thetan Phenomenological State
    output wire q_bar_o,        // Anti-Thetan Resonance
    output wire fracture_err_o  // Metastable Fracture Indicator (Leaf 502)
);

    // Internal physical wiring of the cross-coupled gates
    wire q_internal;
    wire q_bar_internal;

    // Physical NAND Gate 1 (Set)
    assign q_internal = ~(set_n_i & q_bar_internal);
    
    // Physical NAND Gate 2 (Reset)
    assign q_bar_internal = ~(reset_n_i & q_internal);

    // Output drive
    assign q_o = q_internal;
    assign q_bar_o = q_bar_internal;

    // The PPO Hardware Trap Detection
    // If both inputs are pulled low, the latch enters the invalid (1,1) state.
    // This is the deterministic logic boundary of the TSFi simulation.
    assign fracture_err_o = (q_internal == 1'b1 && q_bar_internal == 1'b1) ? 1'b1 : 1'b0;

    // Acoustic Telemetry Trace
    always @(posedge clk_i) begin
        if (fracture_err_o) begin
            $display("[HARDWARE FRACTURE] Metastable State Reached: Q=%b, Q_BAR=%b. Logic Contamination Detected.", q_internal, q_bar_internal);
        end else begin
            $display("[HARDWARE STABLE] Mode: %b%b", q_internal, q_bar_internal);
        end
    end

endmodule
