#include "tsfi_svdag.h"
#include "lau_memory.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <immintrin.h>
#include <stdalign.h>
#include <stdatomic.h>
#include "tsfi_wave512.h"
#include "tsfi_c_math.h"

#define BASIS_COUNT 9
#define LUT_SIZE 1024
static float *g_basis_lut = NULL; 
static _Atomic int g_lut_init_state = 0;

static void init_basis_lut() {
    int expected = 0;
    if (atomic_compare_exchange_strong(&g_lut_init_state, &expected, 1)) {
        g_basis_lut = (float*)lau_memalign(64, BASIS_COUNT * LUT_SIZE * sizeof(float));
        for(int i=0; i<BASIS_COUNT; i++) {
            float freq = (float)(i + 1) * 0.05f;
            for(int k=0; k<LUT_SIZE; k++) {
                g_basis_lut[i * LUT_SIZE + k] = tsfi_sinf(k * freq);
            }
        }
        atomic_store(&g_lut_init_state, 2);
    } else {
        while (atomic_load(&g_lut_init_state) < 2) _mm_pause();
    }
}

TSFiHelmholtzSVDAG* tsfi_svdag_create(size_t initial_cap) {
    TSFiHelmholtzSVDAG* dag = (TSFiHelmholtzSVDAG*)lau_memalign(512, sizeof(TSFiHelmholtzSVDAG));
    if (!dag) return NULL;
    dag->intensity_stream = (float*)lau_memalign(64, initial_cap * sizeof(float));
    dag->phase_stream     = (float*)lau_memalign(64, initial_cap * sizeof(float));
    dag->index_stream     = (uint32_t*)lau_memalign(64, initial_cap * sizeof(uint32_t));
    dag->vrs_map          = (uint8_t*)lau_memalign(64, 128 * 128); // Standard 1024x1024 / 8x8
    dag->vrs_width = 128; dag->vrs_height = 128;
    dag->stream_capacity = initial_cap;
    dag->stream_size = 0;
    dag->max_depth = 0;
    dag->root_entropy = 1.0f;
    dag->is_logical = false;
    dag->logical_glyph = NULL;
    init_basis_lut();
    return dag;
}

void tsfi_svdag_destroy(TSFiHelmholtzSVDAG *dag) {
    if (!dag) return;
    if (dag->intensity_stream) lau_free(dag->intensity_stream);
    if (dag->phase_stream) lau_free(dag->phase_stream);
    if (dag->index_stream) lau_free(dag->index_stream);
    if (dag->vrs_map) lau_free(dag->vrs_map);
    lau_free(dag);
}

void tsfi_svdag_compile(TSFiHelmholtzSVDAG *dag, const TSFiHilbertGlyph *g) {
    if (!dag || !g) return;
    int max_voxels = (int)dag->stream_capacity;
    
    // 1. Calculate Active Mask and Rigidity Metric
    __m512 vW[BASIS_COUNT];
    bool active_mask[BASIS_COUNT];
    int active_count = 0;
    
    for (int i = 0; i < BASIS_COUNT; i++) {
        float weight = g->coeffs[i/3][i%3].real;
        float abs_weight = (weight < 0) ? -weight : weight;
        
        // Rigidity Metric: Weights automatically decay at non-resonant frequencies (beyond basis 4)
        float rigidity_metric = (i < 4) ? 1.0f : 0.85f;
        float effective_weight = weight * rigidity_metric;
        
        if (abs_weight > 1e-6f) {
            vW[i] = _mm512_set1_ps(effective_weight);
            active_mask[i] = true;
            active_count++;
        } else {
            active_mask[i] = false;
        }
    }

    float *out = dag->intensity_stream;
    
    // 2. Neural Pruning Execution (ZMM Saturation)
    if (active_count == 0) {
        memset(out, 0, max_voxels * sizeof(float));
    } else {
        // Optimized active slot iteration
        int active_indices[BASIS_COUNT];
        int actual_active = 0;
        for(int k=0; k<BASIS_COUNT; k++) if(active_mask[k]) active_indices[actual_active++] = k;

        // Deep Unroll (128 voxels per loop) to maximize bus saturation
        for (int i = 0; i <= max_voxels - 128; i += 128) {
            for (int b = 0; b < 8; b++) {
                int secret = i + b*16;
                __m512 vSum = _mm512_setzero_ps();
                int lut_secret = secret % LUT_SIZE;
                
                for (int idx = 0; actual_active > 0 && idx < actual_active; idx++) {
                    int k = active_indices[idx];
                    __m512 vB = _mm512_loadu_ps(&g_basis_lut[k * LUT_SIZE + lut_secret]);
                    vSum = _mm512_fmadd_ps(vB, vW[k], vSum);
                }
                
                // Clamp to zero (ReLU) to ensure non-negative occupancy/norm
                vSum = _mm512_max_ps(vSum, _mm512_setzero_ps());
                _mm512_storeu_ps(&out[secret], vSum);
            }
        }
    }
    dag->stream_size = max_voxels;
}

float tsfi_svdag_execute(const TSFiHelmholtzSVDAG *dag) {
    float volumetric_mass = 0.0f;
    for(size_t i=0; i<dag->stream_size; i++) volumetric_mass += dag->intensity_stream[i];
    
    // The Feynman Point Integral is the trilateral superposition of our potentials.
    // We scale by a large constant to ensure float->uint64 truncation doesn't lose sensitivity.
    float total_mass = volumetric_mass + (dag->p_user + dag->p_deepseek + dag->p_gemini) * 1000000.0f;
    
    return total_mass;
}

void tsfi_svdag_generate_vrs(TSFiHelmholtzSVDAG *dag) {
    if (!dag || !dag->vrs_map) return;
    
    size_t map_size = dag->vrs_width * dag->vrs_height;
    float *intensity = dag->intensity_stream;
    uint8_t *vrs = dag->vrs_map;

    __m512 vHigh = _mm512_set1_ps(0.8f);
    __m512 vMid  = _mm512_set1_ps(0.4f);
    
    // Process map in 64-byte chunks
    for (size_t i = 0; i < map_size && i + 16 <= dag->stream_size; i += 16) {
        __m512 vI = _mm512_loadu_ps(&intensity[i]);
        
        // Masks for shading rates
        __mmask16 m1x1 = _mm512_cmp_ps_mask(vI, vHigh, _CMP_GT_OQ);
        __mmask16 m2x2 = _mm512_mask_cmp_ps_mask(~m1x1, vI, vMid, _CMP_GT_OQ);
        __mmask16 m4x4 = ~(m1x1 | m2x2);

        // Fill byte register
        // VRS Codes: 1x1=0x0, 2x2=0x5, 4x4=0xA
        alignas(64) uint32_t codes[16];
        __m512i vCodes = _mm512_setzero_si512();
        vCodes = _mm512_mask_blend_epi32(m2x2, vCodes, _mm512_set1_epi32(0x5));
        vCodes = _mm512_mask_blend_epi32(m4x4, vCodes, _mm512_set1_epi32(0xA));
        
        _mm512_store_si512(codes, vCodes);
        for(int k=0; k<16; k++) {
            vrs[i + k] = (uint8_t)codes[k];
        }
    }
}

size_t tsfi_proteo_screen_candidates_avx512(const TSFiHelmholtzSVDAG *dag, int candidate_count) {

    size_t len = dag->stream_size;

    __m512 vM = _mm512_set1_ps(0.05f); 

    float global_sum = 0.0f;

    

    // Process candidates in batches of 16 (ZMM width)

    int batches = candidate_count / 16;

    if (batches == 0) batches = 1;



    for (int batch = 0; batch < batches; batch++) { 

        __m512 vA0 = _mm512_setzero_ps();

        // Inner loop: Scan the entire SVDAG for this batch of candidates

        for (size_t i = 0; i <= len - 16; i += 16) {

            __m512 vI = _mm512_loadu_ps(&dag->intensity_stream[i]);

            vA0 = _mm512_fmadd_ps(vI, vM, vA0);

        }

        float tmp[16];

        _mm512_storeu_ps(tmp, vA0);

        global_sum += tmp[0];

    }

    return (size_t)global_sum + candidate_count;

}

float tsfi_svdag_trace_point(const TSFiHelmholtzSVDAG *dag, int x, int y, int z) {
    if (!dag || !dag->intensity_stream) return 0.0f;
    // Linear 128x128x128 mapping assumption
    if (x < 0 || x >= 128 || y < 0 || y >= 128 || z < 0 || z >= 128) return 0.0f;
    size_t idx = (size_t)z * 128 * 128 + (size_t)y * 128 + (size_t)x;
    if (idx >= dag->stream_size) return 0.0f;
    return dag->intensity_stream[idx];
}

void tsfi_svdag_teardown(void) {
    if (g_basis_lut) {
        lau_free(g_basis_lut);
        g_basis_lut = NULL;
        atomic_store(&g_lut_init_state, 0);
    }
}

void tsfi_svdag_cleanup_lut(void) {
    if (g_basis_lut) {
        lau_free(g_basis_lut);
        g_basis_lut = NULL;
        atomic_store(&g_lut_init_state, 0);
    }
}

