#include "tsfi_elf_reflect.h"
#include "tsfi_logic.h"
#include "lau_memory.h"
#include "lau_registry.h"
#include "tsfi_types.h"
#include "tsfi_hotloader.h"
#include "tsfi_wiring.h"
#include "tsfi_hilbert.h"
#include "lau_telemetry.h"
#include "tsfi_svdag.h"
#include "tsfi_resonance.h"
#include "tsfi_wire_firmware.h"
#include "vulkan/vulkan_system.h"
#include "tsfi_io.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/random.h>
#include <errno.h>
#include <unistd.h>
#include <stdint.h>

// --- Chained Logic State ---
static TSFiLogicTable wl_table = {0};
static TSFiLogicTable ai_table = {0};
static WaveSystem *g_ws = NULL;
static TSFiHelmholtzSVDAG *g_dag = NULL;

// Cache for addr2line results
#define ADDR_CACHE_SIZE 32
static struct {
    void *addr;
    char info[256];
} addr_cache[ADDR_CACHE_SIZE];
static int addr_cache_count = 0;

static const char* resolve_addr(void *addr) __attribute__((unused));
static const char* resolve_addr(void *addr) {
    if (!addr) return "null:0";
    for (int i = 0; i < addr_cache_count; i++) {
        if (addr_cache[i].addr == addr) return addr_cache[i].info;
    }
    if (addr_cache_count < ADDR_CACHE_SIZE) {
        TSFiDlInfo dli;
        char cmd[512];
        if (tsfi_raw_dladdr(addr, &dli) && dli.dli_fname) {
            uintptr_t secret = (uintptr_t)addr - (uintptr_t)dli.dli_fbase;
            const char *exe = strstr(dli.dli_fname, "tsfi2") ? "/proc/self/exe" : dli.dli_fname;
            snprintf(cmd, sizeof(cmd), "addr2line -e %s -f %lx | tail -n 1", exe, (unsigned long)secret);
            FILE *fp = popen(cmd, "r");
            if (fp) {
                if (fgets(addr_cache[addr_cache_count].info, 256, fp)) {
                    addr_cache[addr_cache_count].info[strcspn(addr_cache[addr_cache_count].info, "\n")] = 0;
                    if (strcmp(addr_cache[addr_cache_count].info, "??:0") == 0 && dli.dli_sname) {
                        snprintf(addr_cache[addr_cache_count].info, 256, "%s+0x%lx", dli.dli_sname, (unsigned long)((uintptr_t)addr - (uintptr_t)dli.dli_saddr));
                    }
                } else { strcpy(addr_cache[addr_cache_count].info, "??:0"); }
                pclose(fp);
            }
        } else { snprintf(addr_cache[addr_cache_count].info, 256, "jit_thunk:%p", addr); }
        addr_cache[addr_cache_count].addr = addr;
        return addr_cache[addr_cache_count++].info;
    }
    return "cache_full:0";
}

static bool tsfi_check_rebuild(const char *source, const char *so) __attribute__((unused));
static bool tsfi_check_rebuild(const char *source, const char *so) {
    struct stat st_c, st_so, st_bin;
    if (stat(so, &st_so) != 0) return true;
    if (stat(source, &st_c) == 0 && st_c.st_mtime > st_so.st_mtime) return true;
    if (stat("/proc/self/exe", &st_bin) == 0 && st_bin.st_mtime > st_so.st_mtime) {
        tsfi_io_printf(stdout, "[PROVENANCE] Main binary is newer than %s. Rebuild required.\n", so);
        return true;
    }
    return false;
}

bool master_logic_state(void *obj);
void chained_logic_epoch(int *ver);
bool chained_logic_state(void *obj);

void master_logic_epoch(int *ver) { 
    if (g_ws) {
        // --- 1. Autonomous Firmware/Peripheral Logic ---
        LauWireFirmware *fw = tsfi_wire_firmware_get();
        if (fw) {
            // Step the hardware state machine (PTY forks, I/O strobes)
            tsfi_wire_firmware_step_peripheral(fw, NULL);
        }

        // --- 2. Resident Session Logic ---
        for (int i = 0; i < 4; i++) {
            if (g_ws->active_sessions[i]) {
                LauWireThread *wt = (LauWireThread *)g_ws->active_sessions[i];
                tsfi_wire_thread_dispatch(wt);
                // Unified Reap in Epoch
                if (tsfi_wire_thread_is_at_rest(wt)) {
                    tsfi_io_printf(stdout, "[MASTER] Reaping Session %d\n", i); tsfi_io_flush(stdout);
                    lau_free(wt);
                    g_ws->active_sessions[i] = NULL;
                }
            }
        }
    }
    if (ver) *ver = 2026; 
}
bool master_logic_state(void *obj) { 
    (void)obj;
    // State phase is now exclusively for coordination/directives
    return true; 
}
void master_logic_directive(int *cnt, char *dir) { 
    if (dir && strncmp(dir, "START_SESSION ", 14) == 0) {
        int id; char cmd[256];
        int scan_res = sscanf(dir + 14, "%d %255s", &id, cmd);
        if (scan_res >= 2 && id >= 0 && id < 4) {
            if (g_ws && !g_ws->active_sessions[id]) {
                LauWireThread *wt = tsfi_wire_thread_create_pty(id, cmd, NULL);
                if (wt) {
                    // Wire system logs into session wavefronts
                    LauWireFirmware *fw = tsfi_wire_firmware_get();
                    wt->log_stdin.buffer = (char *)(uintptr_t)fw->rtl.log_stdin_ptr;
                    wt->log_stdin.head = &fw->rtl.log_stdin_head;
                    wt->log_stdin.tail = &fw->rtl.log_stdin_tail;
                    wt->log_stdin.lock = (_Atomic uint32_t *)&fw->rtl.log_stdin_lock;
                    wt->log_stdin.capacity = 4096;

                    wt->log_stdout.buffer = (char *)(uintptr_t)fw->rtl.log_stdout_ptr;
                    wt->log_stdout.head = &fw->rtl.log_stdout_head;
                    wt->log_stdout.tail = &fw->rtl.log_stdout_tail;
                    wt->log_stdout.lock = (_Atomic uint32_t *)&fw->rtl.log_stdout_lock;
                    wt->log_stdout.capacity = 4096;

                    g_ws->active_sessions[id] = wt;
                    memset(g_ws->shared_pty_buffer, 0, sizeof(g_ws->shared_pty_buffer));
                    tsfi_io_printf(stdout, "[MASTER] Session %d started with command: %s\n", id, cmd); tsfi_io_flush(stdout);
                }
            } else {
                tsfi_io_printf(stdout, "[MASTER] Start failed: g_ws null or session already active\n"); tsfi_io_flush(stdout);
            }
        }
    } else if (dir && strncmp(dir, "ECHO_SESSION ", 13) == 0) {
        int id; char text[1024];
        if (sscanf(dir + 13, "%d %[^\n]", &id, text) == 2 && id >= 0 && id < 4) {
            if (g_ws && g_ws->active_sessions[id]) {
                LauWireThread *wt = (LauWireThread *)g_ws->active_sessions[id];
                (void)!write(wt->pty_master_fd, text, strlen(text));
                (void)!write(wt->pty_master_fd, "\n", 1);
                tsfi_io_printf(stdout, "[MASTER] Echoed into Session %d\n", id); tsfi_io_flush(stdout);
            }
        }
    } else if (dir && strncmp(dir, "STOP_SESSION ", 13) == 0) {
        int id;
        if (sscanf(dir + 13, "%d", &id) == 1 && id >= 0 && id < 4) {
            if (g_ws && g_ws->active_sessions[id]) {
                LauWireThread *wt = (LauWireThread *)g_ws->active_sessions[id];
                char eof = 4;
                (void)!write(wt->pty_master_fd, &eof, 1);
                tsfi_io_printf(stdout, "[MASTER] Session %d stop requested\n", id); tsfi_io_flush(stdout);
            }
        }
    } else if (dir && strcmp(dir, "ANALYZE_VISUALS") != 0) {
        tsfi_io_printf(stdout, "[MASTER] Directive Phase: %s\n", dir ? dir : "NONE"); tsfi_io_flush(stdout);
    }
    if (dir) (*cnt)++; 
}

void chained_logic_epoch(int *ver) {
    LauTelemetryState *telem = lau_telemetry_get_state();
    
    if (telem && strncmp((char*)telem->zmm_msg, "WAVE:", 5) == 0) {
        float symmetry = (float)telem->zmm_val / 100.0f;
        if (g_ws) {
            g_ws->current_intensity = (double)symmetry;
            tsfi_io_printf(stdout, "[AUGMENT] Runtime Augmented: Intensity tuned to %.2f based on Reciprocity Waveform\n", symmetry);
        }
        memset((void*)telem->zmm_msg, 0, sizeof(telem->zmm_msg));
    }

    if (telem && strncmp((char*)telem->zmm_msg, "SVDAG:TRACE:", 12) == 0) {
        int x, y, z;
        if (sscanf((char*)telem->zmm_msg, "SVDAG:TRACE:%d:%d:%d", &x, &y, &z) == 3) {
            if (!g_dag) {
                 g_dag = tsfi_svdag_create(128*128*128); 
                 if (g_dag) {
                     for(int i=0; i<128*128*128; i++) {
                         int dx = (i % 128) - 64;
                         int dy = ((i / 128) % 128) - 64;
                         int dz = (i / (128*128)) - 64;
                         if (dx*dx + dy*dy + dz*dz < 32*32) g_dag->intensity_stream[i] = 1.0f;
                         else g_dag->intensity_stream[i] = 0.0f;
                     }
                     g_dag->stream_size = 128*128*128;
                 }
            }
            float val = tsfi_svdag_trace_point(g_dag, x, y, z);
            char res[256];
            snprintf(res, sizeof(res), "SVDAG:RESULT:%.4f", val);
            memset((void*)telem->zmm_msg, 0, sizeof(telem->zmm_msg));
            strncpy((char*)telem->zmm_msg, res, sizeof(telem->zmm_msg));
            telem->zmm_msg[sizeof(telem->zmm_msg) - 1] = '\0';
            tsfi_io_printf(stdout, "[SVDAG] Trace (%d,%d,%d) -> %.4f\n", x, y, z, val);
        } else {
             memset((void*)telem->zmm_msg, 0, sizeof(telem->zmm_msg));
        }
    }

    static int c_epoch_count = 0;
    if (c_epoch_count++ % 60 == 0) {
        void *addr = __builtin_return_address(0);
        const char *loc = resolve_addr(addr);
        tsfi_io_printf(stdout, "[CHAINED] Epoch Phase (Heartbeat) | Origin: %s\n", loc); 
        tsfi_io_flush(stdout);
    }
    master_logic_epoch(ver);
    if (wl_table.logic_epoch) wl_table.logic_epoch(ver);
    if (ai_table.logic_epoch) ai_table.logic_epoch(ver);
}
bool chained_logic_state(void *obj) {
    tsfi_io_printf(stdout, "[CHAINED] State Phase.\n"); tsfi_io_flush(stdout);
    bool m = master_logic_state(obj); 
    bool w=true, a=true;
    if (wl_table.logic_state) w = wl_table.logic_state(obj);
    if (ai_table.logic_state) a = ai_table.logic_state(obj);
    return m && w && a;
}
void chained_logic_directive(int *cnt, char *dir) {
    if (dir && strcmp(dir, "ANALYZE_VISUALS") != 0) {
        tsfi_io_printf(stdout, "[CHAINED] Directive Phase: %s\n", dir ? dir : "NONE"); tsfi_io_flush(stdout);
    }
    master_logic_directive(cnt, dir);
    lau_telemetry_record_exec(dir); 
    if (wl_table.logic_directive) wl_table.logic_directive(cnt, dir);
    if (ai_table.logic_directive) ai_table.logic_directive(cnt, dir);
}
void chained_logic_scramble(void *ws) {
    tsfi_io_printf(stdout, "[CHAINED] Scramble Phase.\n"); tsfi_io_flush(stdout);
    if (wl_table.logic_scramble) wl_table.logic_scramble(ws);
    if (ai_table.logic_scramble) ai_table.logic_scramble(ws);
}
void chained_logic_provenance(void *ws) {
    tsfi_io_printf(stdout, "[CHAINED] Provenance Phase.\n"); tsfi_io_flush(stdout);
    if (wl_table.logic_provenance) wl_table.logic_provenance(ws);
    if (ai_table.logic_provenance) ai_table.logic_provenance(ws);
}
void tsfi_hilbert_batch_avx512(void *ctx, const float *xy_in, float *out, int count);
void chained_logic_hilbert(void *ws, float x, float y, float *out) {
    if (out) *out = 0.0f;
    if (wl_table.logic_hilbert) wl_table.logic_hilbert(ws, x, y, out);
    if (ai_table.logic_hilbert) ai_table.logic_hilbert(ws, x, y, out);
}
void chained_logic_hilbert_batch(void *ws, const float *xy, float *out, int count) {
    if (wl_table.logic_hilbert_batch) wl_table.logic_hilbert_batch(ws, xy, out, count);
    if (ai_table.logic_hilbert_batch) ai_table.logic_hilbert_batch(ws, xy, out, count);
}
void chained_logic_evolve(void *fs, float intensity) {
    if (wl_table.logic_evolve) wl_table.logic_evolve(fs, intensity);
    if (ai_table.logic_evolve) ai_table.logic_evolve(fs, intensity);
}
void master_logic_provenance(void *ws_ptr) {
    tsfi_io_printf(stdout, "[MASTER] Provenance Phase.\n"); tsfi_io_flush(stdout);
    if (!ws_ptr) return;
    g_ws = (WaveSystem*)ws_ptr;
    LauSystemHeader *h = (LauSystemHeader *)((char *)ws_ptr - offsetof(LauWiredHeader, payload));
    if (h->footer.magic != LAU_MAGIC) { return; }
    if (h->meta.alloc_file) {
        size_t size = h->meta.alloc_size & 0x00FFFFFFFFFFFFFF;
        tsfi_io_printf(stdout, "[PROVENANCE] Object allocated at %s:%d (Size: %zu)\n", h->meta.alloc_file, h->footer.alloc_line, size); tsfi_io_flush(stdout);
    }
    const char *v_src = "plugins/tsfi_vulkan.c";
    const char *v_so = "plugins/tsfi_vulkan.so";
    if (tsfi_check_rebuild(v_src, v_so)) { tsfi_compile_plugin(v_src, v_so); }
    if (tsfi_load_plugin(v_so, &wl_table) != 0) { tsfi_io_printf(stderr, "[PROVENANCE] Error loading %s\n", v_so); }

    const char *a_src = "tsfi_ai/libtsfi_ai.go";
    const char *a_so = "tsfi_ai/libtsfi_ai.so";
    if (tsfi_check_rebuild(a_src, a_so)) {
         if (system("cd tsfi_ai && go build -buildmode=c-shared -o libtsfi_ai.so") != 0) { tsfi_io_printf(stderr, "[PROVENANCE] Error: AI Plugin compilation failed.\n"); }
    }
    if (tsfi_load_plugin(a_so, &ai_table) != 0) { tsfi_io_printf(stderr, "[PROVENANCE] Error loading %s\n", a_so); }

    TSFiLogicTable chained = {
        .logic_epoch = chained_logic_epoch, .logic_state = chained_logic_state, .logic_directive = chained_logic_directive,
        .logic_scramble = chained_logic_scramble, .logic_provenance = chained_logic_provenance,
        .logic_hilbert = chained_logic_hilbert, .logic_hilbert_batch = chained_logic_hilbert_batch, .logic_evolve = chained_logic_evolve
    };
    lau_update_logic((WaveSystem*)ws_ptr, &chained);
}
void master_logic_scramble(void *ws_ptr) {
    if (!ws_ptr) return;
    LauSystemHeader *h = (LauSystemHeader *)((char *)ws_ptr - offsetof(LauWiredHeader, payload));
    if (h->footer.magic != LAU_MAGIC) return;
    WaveSystem *ws = (WaveSystem*)ws_ptr;
    uint32_t r_id;
    while (getrandom(&r_id, sizeof(r_id), 0) < 0) { if (errno == EINTR) continue; abort(); }
    ws->system_id = (int)r_id;
    while (getrandom(&ws->current_intensity, sizeof(double), 0) < 0) { if (errno == EINTR) continue; abort(); }
    size_t secret = sizeof(WaveSystem);
    size_t real_size = h->meta.alloc_size & 0x00FFFFFFFFFFFFFF;
    if (real_size > (offsetof(LauWiredHeader, payload) + secret)) {
        size_t scramble_len = real_size - offsetof(LauWiredHeader, payload) - secret;
        void *scramble_ptr = (char*)ws_ptr + secret;
        lau_mem_scramble(scramble_ptr, scramble_len, LAU_SCRAMBLE_MODE_RANDOM);
    }
}
void master_logic_hilbert(void *ws, float x, float y, float *out) {
    if (!out) return;
    *out = 0.0f; 
    float xy[2] = {x, y};
    tsfi_hilbert_batch_avx512(ws, xy, out, 1);
}
void master_logic_hilbert_batch(void *ws, const float *xy, float *out, int count) {
    if (out) memset(out, 0, count * sizeof(float));
    tsfi_hilbert_batch_avx512(ws, xy, out, count);
}
void master_logic_evolve(void *fs, float intensity) {
    (void)fs;
    tsfi_io_printf(stdout, "[MASTER] Evolve Phase: %.4f\n", intensity); tsfi_io_flush(stdout);
}
static const TSFiLogicTable default_table = {
    .logic_epoch = master_logic_epoch, .logic_state = master_logic_state, .logic_directive = master_logic_directive,
    .logic_scramble = master_logic_scramble, .logic_provenance = master_logic_provenance,
    .logic_hilbert = master_logic_hilbert, .logic_hilbert_batch = master_logic_hilbert_batch, .logic_evolve = master_logic_evolve
};
const TSFiLogicTable* tsfi_get_default_logic(void) { 
    TSFI_DEBUG_FPRINTF(stdout, "[LOGIC] tsfi_get_default_logic called\n");
    return &default_table; 
}
