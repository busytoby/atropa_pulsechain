#include "tsfi_fourier.h"
#include "lau_memory.h"
#include "tsfi_c_math.h"
#include <string.h>
#include <stdio.h>
#include <immintrin.h>

#ifndef M_PI
#define M_PI TSFI_PI
#endif

#define sinf tsfi_sinf
#define cosf tsfi_cosf

void tsfi_fourier_init_basis(TSFiFourierBasis *basis) {
    if (!basis) return;
    
    // Fill Basis Matrix M (K x 2N)
    // Rows: Time steps t (0..2PI)
    // Cols: cos(1t), sin(1t), cos(2t), sin(2t)...
    
    for (int k = 0; k < TSFI_FOURIER_SAMPLES; k++) {
        float t = (2.0f * M_PI * k) / TSFI_FOURIER_SAMPLES;
        
        for (int n = 0; n < TSFI_FOURIER_HARMONICS; n++) {
            int harmonic = n + 1;
            // Interleaved Cos/Sin for easier SIMD loading
            basis->data[k][n*2 + 0] = cosf(harmonic * t);
            basis->data[k][n*2 + 1] = sinf(harmonic * t);
        }
    }
}

// Convert Coordinate Set to Fourier Coeffs
// Based on Kuhl & Giardina (1982) logic simplified
// Input: xy is flat array of x,y,x,y...
void tsfi_fourier_from_points(TSFiFourierGlyph *out, const float *xy, size_t count) {
    if (!out || !xy || count < 3) return;
    memset(out, 0, sizeof(TSFiFourierGlyph));

    // DFT of the Points (Resampled)
    // Just sum the phasors for the voxels.
    for (int n = 0; n < TSFI_FOURIER_HARMONICS; n++) {
        float an=0, bn=0, cn=0, dn=0;
        int h = n + 1;
        for (size_t i = 0; i < count; i++) {
            float t = (2.0f * M_PI * i) / count;
            float px = xy[i*2+0];
            float py = xy[i*2+1];
            
            an += px * cosf(h*t);
            bn += px * sinf(h*t);
            cn += py * cosf(h*t);
            dn += py * sinf(h*t);
        }
        // Normalize
        out->coeffs[n][0] = an * 2.0f / count;
        out->coeffs[n][1] = bn * 2.0f / count;
        out->coeffs[n][2] = cn * 2.0f / count;
        out->coeffs[n][3] = dn * 2.0f / count;
    }
}

// Reconstruct: V = M * C
// This is the "WMMA" step.
// output_voxels: float buffer [SAMPLES * 2] (x,y interleaved)
void tsfi_fourier_reconstruct_avx512(float *output_voxels, 
                                     const TSFiFourierBasis *basis, 
                                     const TSFiFourierGlyph *glyph) 
{
    // Use dense packed accumulators for the 512 samples
    float acc_x[TSFI_FOURIER_SAMPLES] = {0};
    float acc_y[TSFI_FOURIER_SAMPLES] = {0};

    // Transposed Synthesis (Wavefront Broadcasting)
    // For each harmonic n, we broadcast its Hilbert coefficients (DNA)
    // and apply it to the entire Banach coordinate manifold (512 samples).
    
    for (int n = 0; n < TSFI_FOURIER_HARMONICS; n++) {
        __m512 v_an = _mm512_set1_ps(glyph->coeffs[n][0]);
        __m512 v_bn = _mm512_set1_ps(glyph->coeffs[n][1]);
        __m512 v_cn = _mm512_set1_ps(glyph->coeffs[n][2]);
        __m512 v_dn = _mm512_set1_ps(glyph->coeffs[n][3]);

        // Process 512 samples in 32 tight vectorized steps
        for (int k = 0; k < TSFI_FOURIER_SAMPLES; k += 16) {
            __m512i v_idx = _mm512_set_epi32(15,14,13,12,11,10,9,8,7,6,5,4,3,2,1,0);
            v_idx = _mm512_mullo_epi32(v_idx, _mm512_set1_epi32(TSFI_FOURIER_HARMONICS * 2));
            
            __m512 v_cos = _mm512_i32gather_ps(v_idx, &basis->data[k][n*2+0], 4);
            __m512 v_sin = _mm512_i32gather_ps(v_idx, &basis->data[k][n*2+1], 4);

            // Load Wavefront Accumulators (Unaligned)
            __m512 v_ax = _mm512_loadu_ps(&acc_x[k]);
            __m512 v_ay = _mm512_loadu_ps(&acc_y[k]);

            // FMA: Synthesis step (Matrix Multiply)
            v_ax = _mm512_fmadd_ps(v_an, v_cos, v_ax);
            v_ax = _mm512_fmadd_ps(v_bn, v_sin, v_ax);
            
            v_ay = _mm512_fmadd_ps(v_cn, v_cos, v_ay);
            v_ay = _mm512_fmadd_ps(v_dn, v_sin, v_ay);

            // Store back to cache (Unaligned)
            _mm512_storeu_ps(&acc_x[k], v_ax);
            _mm512_storeu_ps(&acc_y[k], v_ay);
        }
    }

    // Interleave back to output
    for(int i = 0; i < TSFI_FOURIER_SAMPLES; i++) {
        output_voxels[i*2+0] = acc_x[i];
        output_voxels[i*2+1] = acc_y[i];
    }
}