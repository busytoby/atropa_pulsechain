#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <fcntl.h>
#include "tsfi_zmm_vm.h"
#include "lau_memory.h"
#include "tsfi_zmm_rpc.h"
#include "lau_telemetry.h"
#include "tsfi_raw.h"
#include "tsfi_io.h"
#include "tsfi_config.h"

// In-Memory MCP Loop (Bridges stdio and SHM Command Channel)

#include <pthread.h>

static int g_mcp_running = 1;
static LauTelemetryState *g_plugin_telem = NULL;

void* tsfi_mcp_plugin_thread(void* arg) {
    (void)arg;
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stdin, NULL, _IONBF, 0);

    TsfiZmmVmState state;
    tsfi_zmm_vm_init(&state);
    state.telem = g_plugin_telem;

    if (state.telem) {
        tsfi_io_printf(stderr, "[MCP] Unified Plugin Attached to Physical Telemetry Memory.\n");
    }

    size_t cap = 1024 * 1024 * 4; 
    char *input = (char*)lau_malloc(cap);
    char *output = (char*)lau_malloc(cap);
    if (!input || !output) return NULL;

    // --- Initialize Network Bridge (Google Flow Ingest) ---
    int server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd >= 0) {
        int opt = 1;
        setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
        fcntl(server_fd, F_SETFL, O_NONBLOCK);
        
        struct sockaddr_in address;
        address.sin_family = AF_INET;
        address.sin_addr.s_addr = INADDR_ANY;
        int port = 10042;
        const char *p_conf = tsfi_config_get("TSFI_MCP_PORT");
        if (p_conf) port = atoi(p_conf);
        address.sin_port = htons(port);
        
        if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
            tsfi_io_printf(stderr, "[MCP] Network Bind Failed on %d\n", port);
            close(server_fd);
            server_fd = -1;
        } else {
            listen(server_fd, 3);
            tsfi_io_printf(stderr, "[MCP] Google Flow Bridge Listening on Port %d\n", port);
        }
    }

    // Stream Loop
    while (g_mcp_running) {
        // 1. Use Assembly Thunk to poll for SHM Command or Network activity (simulated by timeout)
        if (state.telem) {
            void *paddrs[1] = { (void*)&state.telem->request_cmd[0] };
            uint32_t pmasks[1] = { 0 }; // wait for non-zero
            // We wait up to 10ms using the thunk. If it returns 0, we have a command.
            tsfi_io_wait_wavefront(paddrs, pmasks, 1, 10);
        }

        // 1. Check SHM Command Channel
        if (state.telem && state.telem->request_cmd[0] == '{') {
            char cmd[4096];
            snprintf(cmd, sizeof(cmd), "%.4095s", (char*)state.telem->request_cmd);
            state.telem->request_cmd[0] = 0; // Clear it

            if (tsfi_zmm_rpc_dispatch(&state, cmd, output, cap)) {
                // Write response to SHM for Cockpit to see
                snprintf((char*)state.telem->zmm_msg, sizeof(state.telem->zmm_msg), "%s", output);
                // Also log to stdout for debugging
                tsfi_io_printf(stderr, "[MCP SHM] %s", output);
            }
        }

        fd_set readfds;
        FD_ZERO(&readfds);
        FD_SET(STDIN_FILENO, &readfds);
        int max_fd = STDIN_FILENO;
        
        if (server_fd >= 0) {
            FD_SET(server_fd, &readfds);
            if (server_fd > max_fd) max_fd = server_fd;
        }

        struct timeval tv = {0, 0}; // Immediate check


        // 2. Check Input Sources (Non-blocking select)
        if (select(max_fd + 1, &readfds, NULL, NULL, &tv) > 0) {
            // Check Network (Accept and handle one request at a time for Phase 1)
            if (server_fd >= 0 && FD_ISSET(server_fd, &readfds)) {
                struct sockaddr_in client_addr;
                socklen_t addrlen = sizeof(client_addr);
                int client_fd = accept(server_fd, (struct sockaddr *)&client_addr, &addrlen);
                if (client_fd >= 0) {
                    ssize_t n = read(client_fd, input, cap - 1);
                    if (n > 0) {
                        input[n] = 0;
                        if (tsfi_zmm_rpc_dispatch(&state, input, output, cap)) {
                            ssize_t nw = write(client_fd, output, strlen(output));
                            if (nw < 0) perror("write failed");
                        }
                    }
                    close(client_fd);
                }
            }
        }
        // 3. Asynchronous Epoch Stepper (Non-Blocking LLM Inference)
        tsfi_zmm_rpc_step_async_llm(&state);
        
        tsfi_raw_usleep(1000); // Prevent 100% CPU

    }
    
    lau_free(input);
    lau_free(output);
    
    tsfi_zmm_vm_destroy(&state);
    return NULL;
}

static pthread_t mcp_thread_id;

void tsfi_mcp_plugin_start(LauTelemetryState *t) {
    g_plugin_telem = t;
    g_mcp_running = 1;
    int ret = system("llm_env/bin/python3 tools/daemon_llm.py assets/DeepSeek-Coder-V2-Lite-Instruct.gguf > /tmp/tsfi_daemon.log 2>&1 &");
    (void)ret;
    pthread_create(&mcp_thread_id, NULL, tsfi_mcp_plugin_thread, NULL);
}

void tsfi_mcp_plugin_stop(void) {
    g_mcp_running = 0;
    int ret = system("pkill -f daemon_llm.py > /dev/null 2>&1");
    (void)ret;
    pthread_join(mcp_thread_id, NULL);
}
