# Google Project Flow - Creative Workflow

## Overview
This directory (`creative/`) is the central hub for managing generative video prompts for Google Labs "Project Flow".

## Directory Structure
- **`prompts/`**: Contains text prompts. Each concept should have its own file for easy editing.
    - `000_master_index.md`: The recovered archive.
    - `001_teddy_megalopolis.md`: The "Sick Teddy Bear" scene.
    - `002_poppy_wave.md`: The "DanceCert" performance concepts.
- **`assets/`**: Store downloaded video files here (e.g., `.mp4`).

## How to Add a New Prompt
1.  Create a new file in `prompts/` (e.g., `003_cyberpunk_rain.md`).
2.  Paste your text.
3.  (Optional) Add metadata like `Model: Veo 2` or `Status: Draft`.

## Synchronization (Manual)
Since direct API access is restricted/experimental:
1.  **Input:** Copy text from `prompts/*.md` and paste into the Google Labs web interface.
2.  **Output:** Download the generated video and move it to `assets/`.
3.  **Log:** Update the status in the prompt file (e.g., "Generated on 2026-02-08").

## Automation Status
- **Scripts:** `tools/fetch_flow_history.sh` exists but currently requires a fresh OAuth token and correct endpoint discovery.
- **Cookie:** Session tokens can be extracted from `~/.config/google-chrome/Default/Cookies` if `sqlite3` is installed.
