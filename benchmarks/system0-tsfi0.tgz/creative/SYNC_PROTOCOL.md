# Google Labs Project Flow - Sync Protocol (Phase 0)

To keep the local `creative/` directory in sync with the **Google Labs Web Interface**, follow this protocol.

## Prerequisite
- You are logged into `https://labs.google/fx/tools/flow` in Chrome.
- You have opened **DevTools** (`F12`).

## Step 1: Extract (Browser)
1.  Copy the code from `tools/extract_browser_history.js`.
2.  Paste it into the **Console** tab of DevTools.
3.  Press Enter.
4.  **Copy** the JSON object output (right-click -> "Copy object").

## Step 2: Transfer (Bridge)
1.  Create/Overwrite `creative/raw_browser_dump.json`.
2.  Paste the JSON content into it.
3.  Save the file.

## Step 3: Process (Automated)
Run the import tool to parse the dump and generate Markdown files:

```bash
python3 tools/import_flow_dump.py
```

## Step 4: Verify
Check `creative/prompts/` to see your newly synced files.

---
**Why this method?**
The Google Labs Web UI uses an internal, undocumented API that is separate from the `google-genai` Developer API. This "Dump & Parse" method is robust, secure, and requires no API key management.
