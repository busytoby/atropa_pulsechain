#include "tsfi_wire_firmware.h"
#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>
#include "tsfi_dysnomia.h"
#include "tsfi_reaction.h"

LauWireFirmware* tsfi_wire_firmware_get_no_init(void) {
    return NULL;
}

void freeYI(struct YI* p) { (void)p; }
void freeDAI(struct Dai* p) { (void)p; }
struct YI* tsfi_reaction_shoot(TSFiBigInt* p) { (void)p; return NULL; }

int g_init_in_progress = 0;
void tsfi_vision_classify_thunk(void) {}
void* tsfi_memset(void* p, int v, size_t s) { (void)v;(void)s; return p; }
uint64_t get_time_ns(void) { return 0; }
void tsfi_video_write_frame(void* p) { (void)p; }
struct Dai* ReactSHIO_bn_reused(struct Dai* dI, struct SHIO* Mu, TSFiBigInt* pi_bn) { (void)Mu;(void)pi_bn; return dI; }
