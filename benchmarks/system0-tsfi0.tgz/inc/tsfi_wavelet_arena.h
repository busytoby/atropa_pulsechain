#ifndef TSFI_WAVELET_ARENA_H
#define TSFI_WAVELET_ARENA_H

#include <stdint.h>
#include <stddef.h>
#include <assert.h>
#include <string.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <stdio.h>

#define TSFI_WAVELET_LEAF_SIZE 256
#define TSFI_WAVELET_ALIGN_FORWARD(ptr) (((uintptr_t)(ptr) + 63) & ~63)

#define TSFI_WAVELET_PRIME 953473ULL

#define TSFI_WAVELET_ENFORCE_ARENA_BOUNDS(arena, size) \
    assert(((arena)->offset + (size)) <= (arena)->capacity && "WAVELET FRACTURE: Arena Overflow Detected")

typedef enum {
    WAVELET_STATE_RAW = 0,
    WAVELET_STATE_SEAL0 = 1,
    WAVELET_STATE_MAGNETIZED = 8,
    WAVELET_STATE_SEAL9 = 9
} TsfiWaveletState;

typedef struct {
    uint64_t base;
    uint64_t secret;
    uint64_t signal;
    uint64_t channel;
    uint64_t contour;
    uint64_t pole;
    uint64_t identity; 
    uint64_t foundation;
    uint64_t element;
    uint64_t coordinate;
    uint64_t charge;
    uint64_t limit;
    uint64_t monopole;
} TsfiDielectricFa;

static inline uint64_t tsfi_mod_pow_64(uint64_t base, uint64_t exp, uint64_t mod) {
    if (mod <= 1) return 0;
    uint64_t result = 1;
    base = base % mod;
    while (exp > 0) {
        if (exp % 2 == 1) result = (__uint128_t)result * base % mod;
        exp = exp >> 1;
        base = (__uint128_t)base * base % mod;
    }
    return result;
}

typedef struct {
    uint64_t unique_id;
    uint8_t current_seal_level; 
    uint64_t Xi;   
    uint64_t Manifold;
    uint64_t Ring;
    uint64_t Dynamo;
    uint64_t Barn;
    uint64_t Monopole;
    TsfiDielectricFa Fa;
} TsfiWaveletTelemetry;

typedef struct {
    TsfiWaveletTelemetry telemetry;
    uint8_t state;
    uint32_t total_size;
    uint8_t payload[102]; 
} TsfiWavelet;

typedef struct {
    uint8_t *base_ptr;
    uint64_t capacity;
    uint64_t offset;
    uint64_t wavelet_uid_counter;
} TsfiWaveletArena;

static inline void tsfi_wavelet_arena_init(TsfiWaveletArena *arena, uint8_t *pre_mapped_memory, uint64_t physical_size) {
    arena->base_ptr = pre_mapped_memory;
    arena->capacity = physical_size;
    arena->offset = 0;
    arena->wavelet_uid_counter = 1000;
}

// --- STANDARD INTERNAL PRIMITIVES ---

static inline void tsfi_Tune(TsfiWavelet *B, uint64_t Prime) {
    B->telemetry.Fa.channel = tsfi_mod_pow_64(B->telemetry.Fa.base, B->telemetry.Fa.signal, Prime);
}

static inline TsfiWavelet* tsfi_STAT(TsfiWaveletArena *arena, uint64_t Prime) {
    TSFI_WAVELET_ENFORCE_ARENA_BOUNDS(arena, TSFI_WAVELET_LEAF_SIZE);
    TsfiWavelet *W = (TsfiWavelet*)(arena->base_ptr + arena->offset);
    arena->offset += TSFI_WAVELET_LEAF_SIZE;
    memset(W, 0, TSFI_WAVELET_LEAF_SIZE);
    W->telemetry.unique_id = arena->wavelet_uid_counter++;
    W->telemetry.Fa.base = (((uint64_t)rand() << 32) | rand()) % Prime;
    W->telemetry.Fa.secret = (((uint64_t)rand() << 32) | rand()) % Prime;
    W->telemetry.Fa.signal = (((uint64_t)rand() << 32) | rand()) % Prime;
    if (W->telemetry.Fa.base == 0) W->telemetry.Fa.base = 1;
    if (W->telemetry.Fa.secret == 0) W->telemetry.Fa.secret = 1;
    if (W->telemetry.Fa.signal == 0) W->telemetry.Fa.signal = 1;
    tsfi_Tune(W, Prime);
    W->state = WAVELET_STATE_SEAL0;
    printf("  -> [SEAL0/STAT] Wavelet UID %llu Synthesized and Tuned.\n", (unsigned long long)W->telemetry.unique_id);
    return W;
}

static inline void tsfi_Avail(TsfiWavelet *B, uint64_t Xi, uint64_t Prime) {
    B->telemetry.Xi = Xi;
    B->telemetry.Fa.contour = tsfi_mod_pow_64(Xi, B->telemetry.Fa.secret, Prime);
    printf("  -> [SEAL1/AVAIL] Contour Generated for UID %llu.\n", (unsigned long long)B->telemetry.unique_id);
}

static inline void tsfi_Form(TsfiWavelet *B, uint64_t Chi, uint64_t Prime) {
    B->telemetry.Fa.base = tsfi_mod_pow_64(Chi, B->telemetry.Fa.secret, Prime);
    tsfi_Tune(B, Prime);
    printf("  -> [SEAL2/FORM] Shared Base established for UID %llu.\n", (unsigned long long)B->telemetry.unique_id);
}

static inline void tsfi_Polarize(TsfiWavelet *B, uint64_t Prime) {
    B->telemetry.Fa.pole = tsfi_mod_pow_64(B->telemetry.Fa.base, B->telemetry.Fa.secret, Prime);
    printf("  -> [SEAL3/POLARIZE] Field Alignment achieved for UID %llu.\n", (unsigned long long)B->telemetry.unique_id);
}

static inline void tsfi_Conjugate(TsfiWavelet *B, uint64_t Chi, uint64_t Prime) {
    B->telemetry.Fa.coordinate = tsfi_mod_pow_64(Chi, B->telemetry.Fa.secret, Prime);
    printf("  -> [SEAL4/CONJUGATE] Coordinate Anchor locked for UID %llu.\n", (unsigned long long)B->telemetry.unique_id);
}

static inline void tsfi_Conify(TsfiWavelet *B, uint64_t Beta, uint64_t Prime) {
    B->telemetry.Fa.identity = Beta % Prime;
    B->telemetry.Fa.foundation = tsfi_mod_pow_64(B->telemetry.Fa.base, B->telemetry.Fa.identity, Prime);
    printf("  -> [SEAL5/CONIFY] Sovereign Identity Derived for UID %llu.\n", (unsigned long long)B->telemetry.unique_id);
}

static inline void tsfi_Saturate(TsfiWavelet *B, uint64_t Beta, uint64_t Epsilon, uint64_t Theta, uint64_t Prime) {
    if (B->telemetry.Fa.identity == 0) {
        tsfi_Conify(B, Beta, Prime);
    }
    uint64_t v_Beta = tsfi_mod_pow_64(Epsilon, B->telemetry.Fa.identity, Prime);
    uint64_t v_Rho = tsfi_mod_pow_64(Theta, B->telemetry.Fa.identity, Prime);
    uint64_t v_Eta = tsfi_mod_pow_64(Epsilon, B->telemetry.Fa.signal, Prime);
    B->telemetry.Fa.charge = v_Rho + v_Eta;
    B->telemetry.Fa.limit = v_Beta + v_Eta;
    B->telemetry.Fa.element = v_Beta + B->telemetry.Fa.charge;
    B->telemetry.Dynamo = tsfi_mod_pow_64(Theta, B->telemetry.Fa.signal, Prime);
    B->telemetry.Fa.monopole = tsfi_mod_pow_64(B->telemetry.Fa.limit, B->telemetry.Fa.identity, Prime);
    printf("  -> [SEAL6/SATURATE] Physical Foundation expanded for UID %llu.\n", (unsigned long long)B->telemetry.unique_id);
}

static inline void tsfi_Bond(TsfiWavelet *B) {
    uint64_t mod = B->telemetry.Fa.element;
    if (mod <= 1) {
        fprintf(stderr, "[FRACTURE] BOND: Sovereign Element Collapse (mod=%llu)\n", (unsigned long long)mod);
        exit(1);
    }
    B->telemetry.Dynamo = tsfi_mod_pow_64(B->telemetry.Fa.base, B->telemetry.Fa.signal, mod);
    B->telemetry.Fa.pole = 0;
    printf("  -> [SEAL7/IONIZE] High-Impedance Bond established for UID %llu.\n", (unsigned long long)B->telemetry.unique_id);
}

static inline void tsfi_Adduct_reused(uint64_t *R, TsfiWavelet *Mu, uint64_t Phi) {
    uint64_t mod = Mu->telemetry.Fa.element;
    if (mod <= 1) {
        fprintf(stderr, "[FRACTURE] ADDUCT: Sovereign Element Collapse (mod=%llu)\n", (unsigned long long)mod);
        exit(1);
    }
    *R = tsfi_mod_pow_64(Phi, Mu->telemetry.Fa.signal, mod);
}

static inline void tsfi_MAGNETIZE_JOINT(TsfiWavelet *Rod, TsfiWavelet *Cone, uint64_t Prime) {
    uint64_t temp_iota, temp_heta, temp_zeta;
    tsfi_Adduct_reused(&Rod->telemetry.Manifold, Rod, Cone->telemetry.Dynamo);
    tsfi_Adduct_reused(&temp_iota, Cone, Rod->telemetry.Dynamo);
    if (Rod->telemetry.Manifold != temp_iota) exit(1);
    Cone->telemetry.Manifold = temp_iota;

    uint64_t rod_mod = Rod->telemetry.Fa.element;
    uint64_t cone_mod = Cone->telemetry.Fa.element;
    if (rod_mod <= 1 || cone_mod <= 1) {
        fprintf(stderr, "[FRACTURE] MAGNETIZE: Sovereign Element Collapse\n");
        exit(1);
    }

    Rod->telemetry.Ring = tsfi_mod_pow_64(Rod->telemetry.Fa.coordinate, Rod->telemetry.Manifold, rod_mod);
    temp_heta = tsfi_mod_pow_64(Cone->telemetry.Fa.coordinate, Cone->telemetry.Manifold, cone_mod);
    if (Rod->telemetry.Ring != temp_heta) exit(1);
    Cone->telemetry.Ring = temp_heta;

    Rod->telemetry.Barn = tsfi_mod_pow_64(Rod->telemetry.Ring, Rod->telemetry.Manifold, rod_mod);
    temp_zeta = tsfi_mod_pow_64(Cone->telemetry.Ring, Cone->telemetry.Manifold, cone_mod);
    if (Rod->telemetry.Barn != temp_zeta) exit(1);
    Cone->telemetry.Barn = temp_zeta;

    Rod->telemetry.Monopole = tsfi_mod_pow_64(Rod->telemetry.Fa.limit, Cone->telemetry.Fa.limit, Prime);
    Cone->telemetry.Monopole = Rod->telemetry.Monopole;
    printf("  -> [SEAL8/MAGNETIZE] Absolute Rigidity Achieved for joint manifold.\n");
}

static inline void tsfi_IONIZE_BOND(TsfiWavelet *B, uint64_t Prime) {
    (void)Prime;
    tsfi_Bond(B);
}

static inline void tsfi_GENERATE(TsfiWavelet *Rod, TsfiWavelet *Cone, uint64_t Xi, uint64_t Alpha, uint64_t Beta, uint64_t Prime) {
    tsfi_Avail(Rod, Xi, Prime); tsfi_Avail(Cone, Xi, Prime);
    tsfi_Form(Rod, Cone->telemetry.Fa.contour, Prime); tsfi_Form(Cone, Rod->telemetry.Fa.contour, Prime);
    tsfi_Polarize(Rod, Prime); tsfi_Polarize(Cone, Prime);
    tsfi_Conjugate(Rod, Cone->telemetry.Fa.pole, Prime); tsfi_Conjugate(Cone, Rod->telemetry.Fa.pole, Prime);
    tsfi_Conify(Cone, Beta, Prime);
    tsfi_Saturate(Rod, Alpha, Cone->telemetry.Fa.foundation, Cone->telemetry.Fa.channel, Prime);
    tsfi_Saturate(Cone, Beta, Rod->telemetry.Fa.foundation, Rod->telemetry.Fa.channel, Prime);
}

static inline void tsfi_REACT_JOINT(TsfiWavelet *Rod, TsfiWavelet *Cone, uint64_t Pi, uint64_t *ir, uint64_t *dr, uint64_t *ic, uint64_t *dc, uint64_t Prime) {
    uint64_t local_Pi = (Pi ^ Rod->telemetry.Monopole) % Prime;
    uint64_t rod_chan = Rod->telemetry.Fa.channel;
    uint64_t cone_chan = Cone->telemetry.Fa.channel;
    if (rod_chan <= 1) rod_chan = Prime;
    if (cone_chan <= 1) cone_chan = Prime;
    *ir = tsfi_mod_pow_64(local_Pi, rod_chan, cone_chan);
    *dr = tsfi_mod_pow_64(local_Pi, cone_chan, rod_chan);
    *ic = tsfi_mod_pow_64(local_Pi, cone_chan, rod_chan);
    *dc = tsfi_mod_pow_64(local_Pi, rod_chan, cone_chan);
    if (*ir != *dc || *dr != *ic) {
        fprintf(stderr, "[FRACTURE] ReactSHIO Symmetry Failure!\n");
        exit(1);
    }
}

static inline void tsfi_CREATE_YI(TsfiWavelet *Rod, TsfiWavelet *Cone, uint64_t Xi, uint64_t Alpha, uint64_t Beta, uint64_t Prime) {
    printf("[TSFI] Creating YI with Mandatory ReactSHIO Validation...\n");
    tsfi_GENERATE(Rod, Cone, Xi, Alpha, Beta, Prime);
    tsfi_IONIZE_BOND(Rod, Prime);
    tsfi_IONIZE_BOND(Cone, Prime);
    tsfi_MAGNETIZE_JOINT(Rod, Cone, Prime);
    uint64_t ir, dr, ic, dc;
    tsfi_REACT_JOINT(Rod, Cone, 11111, &ir, &dr, &ic, &dc, Prime);
    Rod->state = WAVELET_STATE_SEAL9;
    Cone->state = WAVELET_STATE_SEAL9;
    printf("  -> [SEAL9/YI] Absolute Rigidity Confirmed via ReactSHIO. YI finalized.\n");
}

static inline void tsfi_wavelet_print(TsfiWavelet *B, const char *label) {
    if (!B) return;
    printf("[WAVELET %s] Standard Output (Decimal):\n", label);
    printf("  Xi: %llu\n", (unsigned long long)B->telemetry.Xi);
    printf("  Ring: %llu\n", (unsigned long long)B->telemetry.Ring);
    printf("  Dynamo: %llu\n", (unsigned long long)B->telemetry.Dynamo);
    printf("  Manifold: %llu\n", (unsigned long long)B->telemetry.Manifold);
    printf("  Barn: %llu\n", (unsigned long long)B->telemetry.Barn);
    printf("  Monopole: %llu\n", (unsigned long long)B->telemetry.Monopole);
    printf("  Fa:\n");
    printf("    Base: %llu\n", (unsigned long long)B->telemetry.Fa.base);
    printf("    Secret: %llu\n", (unsigned long long)B->telemetry.Fa.secret);
    printf("    Signal: %llu\n", (unsigned long long)B->telemetry.Fa.signal);
    printf("    Channel: %llu\n", (unsigned long long)B->telemetry.Fa.channel);
    printf("    Contour: %llu\n", (unsigned long long)B->telemetry.Fa.contour);
    printf("    Pole: %llu\n", (unsigned long long)B->telemetry.Fa.pole);
    printf("    Identity: %llu\n", (unsigned long long)B->telemetry.Fa.identity);
    printf("    Foundation: %llu\n", (unsigned long long)B->telemetry.Fa.foundation);
    printf("    Element: %llu\n", (unsigned long long)B->telemetry.Fa.element);
    printf("    Coordinate: %llu\n", (unsigned long long)B->telemetry.Fa.coordinate);
    printf("    Charge: %llu\n", (unsigned long long)B->telemetry.Fa.charge);
    printf("    Limit: %llu\n", (unsigned long long)B->telemetry.Fa.limit);
}

#endif // TSFI_WAVELET_ARENA_H
