#!/bin/bash
# TSFi .tsfi Suite Verbose Verification Script

BOLD="\033[1m"
GREEN="\033[32m"
RED="\033[31m"
CYAN="\033[36m"
RESET="\033[0m"

TSFIC="tools/tsfic_compiler.py"
SAMPLES=(
    "demo.tsfi"
    "sandbox/block_zero_genesis.tsfi"
    "sandbox/block_zero_quality.tsfi"
    "sandbox/block_zero_ultra.tsfi"
    "sandbox/create_yi_demo.tsfi"
    "sandbox/master_resonance.tsfi"
    "sandbox/ppo_resonance.tsfi"
    "sandbox/test_fa_tune.tsfi"
    "sandbox/test_fa_wavelet.tsfi"
    "sandbox/test_fuse_rigidity.tsfi"
    "sandbox/test_reaction.tsfi"
    "sandbox/test_sha_wavelet.tsfi"
    "sandbox/test_standard_fuse.tsfi"
    "sandbox/test_standard_handshake.tsfi"
    "sandbox/test_wavelet.tsfi"
)

mkdir -p bin/tsfi_samples

for sample in "${SAMPLES[@]}"; do
    base=$(basename "$sample" .tsfi)
    printf "\n${BOLD}${CYAN}=== VERIFYING %s ===${RESET}\n" "$sample"
    
    # 1. Transpilation
    python3 "$TSFIC" "$sample" "bin/tsfi_samples/${base}.c" > /dev/null
    if [ $? -ne 0 ]; then
        printf "  [${RED}FAIL${RESET}] Transpilation Failed.\n"
        exit 1
    fi
    
    # 2. Compilation (Lightweight Linkage)
    gcc -Wall -Wextra -std=c11 -D_POSIX_C_SOURCE=200809L -D_GNU_SOURCE -Iinc -Iplugins -Iplugins/vulkan -Isrc -O3 -march=native -flax-vector-conversions -o "bin/tsfi_samples/${base}" \
        "bin/tsfi_samples/${base}.c" \
        src/tsfi_merkle.c src/tsfi_math.c src/tsfi_pool.c src/lau_memory.c src/lau_registry.c src/tsfi_io.c src/tsfi_hilbert.c src/tsfi_vec_math.c src/lau_thunk.c src/tsfi_svdag.c src/tsfi_dys_math.c tests/dummy_firmware.c -rdynamic -lpthread -lm -latomic
    
    if [ $? -ne 0 ]; then
        printf "  [${RED}FAIL${RESET}] Compilation Failed.\n"
        exit 1
    fi
    
    # 3. Verbose Execution
    printf "${BOLD}Physical Telemetry Trace:${RESET}\n"
    "./bin/tsfi_samples/${base}"
    
    if [ $? -ne 0 ]; then
        printf "  [${RED}FRACTURE${RESET}] Rigidity Audit Failed.\n"
        exit 1
    fi
    
    printf "\n[${GREEN}PASS${RESET}] %s Verified Rigid.\n" "$sample"
done

printf "\n${BOLD}${GREEN}All 15 .tsfi Code Tests Passed Verbatim Standard with Full Telemetry.${RESET}\n"
