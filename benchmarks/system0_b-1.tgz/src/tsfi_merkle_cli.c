#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include "tsfi_merkle.h"
#include "tsfi_io.h"
#include "tsfi_c_math.h"

void print_hex(const char *label, const uint8_t *data, size_t len) {
    printf("%s: ", label);
    for (size_t i = 0; i < len; i++) printf("%02x", data[i]);
    printf("\n");
}

void usage(const char *prog) {
    printf("Usage: %s <command> [args]\n", prog);
    printf("Commands:\n");
    printf("  inspect <manifold.pos>          Show manifold roots and metadata\n");
    printf("  verify <manifold.pos> <leaf>    Verify inclusion proof for a leaf\n");
    printf("  cornu <epoch>                   Show Cornu Spiral coordinates (C, S) for epoch\n");
}

int main(int argc, char **argv) {
    if (argc < 2) {
        usage(argv[0]);
        return 1;
    }

    const char *cmd = argv[1];

    if (strcmp(cmd, "inspect") == 0) {
        if (argc < 3) { usage(argv[0]); return 1; }
        void *manifold = malloc(512 * 1024);
        if (tsfi_restore_manifold(argv[2], manifold, 512 * 1024) != 0) {
            fprintf(stderr, "Failed to load manifold: %s\n", argv[2]);
            free(manifold);
            return 1;
        }
        uint8_t root[32], receipt[32];
        tsfi_merkle_init();
        tsfi_merkle_reduce_11(root, receipt, manifold, 1, 2026, NULL);
        print_hex("State Root", root, 32);
        print_hex("Receipt Root", receipt, 32);
        free(manifold);
    } 
    else if (strcmp(cmd, "verify") == 0) {
        if (argc < 4) { usage(argv[0]); return 1; }
        void *manifold = malloc(512 * 1024);
        if (tsfi_restore_manifold(argv[2], manifold, 512 * 1024) != 0) {
            fprintf(stderr, "Failed to load manifold: %s\n", argv[2]);
            free(manifold);
            return 1;
        }
        int leaf_idx = atoi(argv[3]);
        uint8_t proof[32];
        tsfi_merkle_get_proof(proof, leaf_idx, manifold);
        printf("Leaf %d Inclusion Proof (Residue):\n", leaf_idx);
        print_hex("  Proof", proof, 32);
        free(manifold);
    }
    else if (strcmp(cmd, "lore") == 0) {
        if (argc < 5) {
            printf("Usage: %s lore <manifold.pos> <leaf_offset> <text>\n", argv[0]);
            return 1;
        }
        void *manifold = malloc(512 * 1024);
        tsfi_restore_manifold(argv[2], manifold, 512 * 1024);
        int offset = atoi(argv[3]);
        const char *text = argv[4];
        
        uint8_t *directive_region = (uint8_t*)manifold + (TSFI_TOTAL_LEAVES * 256);
        uint8_t *stored_hash = directive_region + (offset * 256);
        
        uint8_t input_hash[32];
        tsfi_keccak256((const uint8_t*)text, strlen(text), input_hash);
        
        printf("Lore Verification for Leaf %d:\n", offset);
        print_hex("  Stored Hash", stored_hash, 32);
        print_hex("  Input Hash ", input_hash, 32);
        
        if (memcmp(stored_hash, input_hash, 32) == 0) {
            printf("[PASS] Lore Verified: Text matches trilateral manifold record.\n");
        } else {
            printf("[FAIL] Lore Mismatch: Manifold contains different lore.\n");
        }
        free(manifold);
    }
    else if (strcmp(cmd, "cornu") == 0) {
        if (argc < 3) { usage(argv[0]); return 1; }
        float u = atof(argv[2]);
        extern float tsfi_fresnel_c(float u);
        extern float tsfi_fresnel_s(float u);
        float C = tsfi_fresnel_c(u);
        float S = tsfi_fresnel_s(u);
        printf("Epoch %f -> Cornu(C: %f, S: %f)\n", (double)u, (double)C, (double)S);
    }
    else {
        usage(argv[0]);
        return 1;
    }

    return 0;
}
