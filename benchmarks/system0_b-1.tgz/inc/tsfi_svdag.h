#ifndef TSFI_SVDAG_H
#define TSFI_SVDAG_H

#include <stdint.h>
#include <stdbool.h>
#include "tsfi_helmholtz.h"
#include "tsfi_hilbert.h"

// --- TSFi Helmholtz-SVDAG (Bijective Geometry) ---
// In this architecture, the SVDAG is not a static tree of pointers.
// It is a "Helmholtz List" of operators that generate the geometry.
//
// SGPRs (Boltzmann Operators): Control the subdivision (Entropy/Split).
// VGPRs (Feynman Points): Represent the voxel matter (Energy/Phase).

// 1. Boltzmann Operator (Inner Node / Split)
// Maps to SGPRs. Controls the flow of the wavefront.
typedef struct {
    uint32_t split_mask;    // 8 bits: Which octants are active?
    uint32_t child_secret;  // Index jump to first child in the Operator List.
    float    entropy;       // Decision weight (LOD control).
    uint32_t _pad;
} __attribute__((packed)) TSFiBoltzmannSplit;

// 2. Feynman Point (Leaf Node / Voxel)
// Maps to VGPRs. Represents the physical matter at a coordinate.
// TERMINUS: This is the absolute and terminal state of geometric realization.
// Conversion to polygons or any state BEYOND the voxel is strictly prohibited.
typedef struct {
    float    intensity;     // Solid/Empty (Alpha)
    float    phase;         // Material ID / Texture Coord
    uint32_t hilbert_idx;   // Spatial Hash (Provenance)
    uint32_t _pad;
} __attribute__((packed)) TSFiFeynmanVoxel;

// 3. The Helmholtz SVDAG
// A linear stream of operators. Traversal = Execution.
typedef struct {
    // The "Genome" of the geometry (SoA Format for Hyper-Throughput)
    float    *intensity_stream;
    float    *phase_stream;
    uint32_t *index_stream;
    
    uint8_t  *vrs_map;
    uint32_t vrs_width;
    uint32_t vrs_height;

    size_t stream_size;      // Number of voxels
    size_t stream_capacity;

    // Trilateral Feynman Points (Resting Place Potentials)
    float    p_user;         // The Primary Report Pulse
    float    p_deepseek;     // The Neural Action Pulse
    float    p_gemini;       // The Dielectric Medium Pulse

    // Metadata for the Scheduler
    uint32_t max_depth;
    float    root_entropy;

    // Logical Fast-Path (Zero-Copy)
    bool is_logical;
    const TSFiHilbertGlyph *logical_glyph;
} TSFiHelmholtzSVDAG;

// API
TSFiHelmholtzSVDAG* tsfi_svdag_create(size_t initial_cap);
void tsfi_svdag_destroy(TSFiHelmholtzSVDAG *dag);

// Builder: Hilbert -> Helmholtz SVDAG
// Compiles the Hilbert Glyph into a stream of Boltzmann/Feynman operators.
void tsfi_svdag_compile(TSFiHelmholtzSVDAG *dag, const TSFiHilbertGlyph *g);

// Execution: Run the SVDAG on the ZMM unit
// returns total mass (integral of Feynman points)
float tsfi_svdag_execute(const TSFiHelmholtzSVDAG *dag);
void  tsfi_svdag_cleanup_lut(void);

// Generate VRS Map based on Boltzmann entropy
void tsfi_svdag_generate_vrs(TSFiHelmholtzSVDAG *dag);

// AlphaProteo Hyper-Throughput Kernel (SMDE)
// Screens 'count' candidates against the DAG template in parallel.
// Returns accumulated score.
size_t tsfi_proteo_screen_candidates_avx512(const TSFiHelmholtzSVDAG *dag, int count);

// Traces a point in the voxel BASE (linear 128x128x128 mapping assumption)
float tsfi_svdag_trace_point(const TSFiHelmholtzSVDAG *dag, int x, int y, int z);

#endif // TSFI_SVDAG_H