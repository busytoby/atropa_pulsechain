#include <unistd.h>
#include "tsfi_wiring.h"
#include "tsfi_hotloader.h"
#include "lau_memory.h"
#include "tsfi_merkle.h"
#include "tsfi_io.h"
#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <string.h>

int main() {
    alarm(5);
    puts("--- RUNNING PERSISTENCE TEST ---");
    
    // 1. Initialize System
    WaveSystem *ws = tsfi_create_system();
    if (!ws) {
        fprintf(stderr, "Failed to create system\n");
        return 1;
    }
    
    // Verify Initial State
    if (*ws->version != 0) {
        fprintf(stderr, "FAIL: Initial version not 0\n");
        return 1;
    }

    // 2. Compile Plugins
    if (tsfi_compile_plugin("plugins/plugin_a.c", "plugins/plugin_a.so") != 0) {
        fprintf(stderr, "FAIL: Compile A\n");
        return 1;
    }
    if (tsfi_compile_plugin("plugins/plugin_b.c", "plugins/plugin_b.so") != 0) {
        fprintf(stderr, "FAIL: Compile B\n");
        return 1;
    }

    // 3. Load Plugin A
    puts("[TEST] Loading Plugin A...");
    TSFiLogicTable logic_a;
    if (tsfi_load_plugin("plugins/plugin_a.so", &logic_a) != 0) return 1;
    lau_update_logic(ws, &logic_a);
    
    // 4. Execute Epoch (A sets to 100)
    ws->step_safety_epoch();
    printf("[TEST] Version after A: %d\n", *ws->version);
    ws->provenance(); // Verify symbol resolution
    
    if (*ws->version != 100) {
        fprintf(stderr, "FAIL: Plugin A did not set version to 100.\n");
        return 1;
    }

    // 5. Load Plugin B
    puts("[TEST] Loading Plugin B...");
    TSFiLogicTable logic_b;
    if (tsfi_load_plugin("plugins/plugin_b.so", &logic_b) != 0) return 1;
    lau_update_logic(ws, &logic_b);
    
    // 6. Execute Epoch (B adds 50)
    ws->step_safety_epoch();
    printf("[TEST] Version after B: %d\n", *ws->version);
    ws->provenance(); // Verify symbol resolution
    
    // Load Plugin C
    puts("[TEST] Loading Plugin C...");
    TSFiLogicTable logic_c;
    if (tsfi_compile_plugin("plugins/plugin_c.c", "plugins/plugin_c.so") != 0) {
        fprintf(stderr, "FAIL: Compile C\n");
        return 1;
    }
    if (tsfi_load_plugin("plugins/plugin_c.so", &logic_c) != 0) return 1;
    lau_update_logic(ws, &logic_c);
    
    // Execute Epoch (C doubles version)
    ws->step_safety_epoch();
    printf("[TEST] Version after C: %d\n", *ws->version);
    ws->provenance(); // Verify symbol resolution

    // Load Plugin D
    puts("[TEST] Loading Plugin D...");
    TSFiLogicTable logic_d;
    if (tsfi_compile_plugin("plugins/plugin_d.c", "plugins/plugin_d.so") != 0) {
        fprintf(stderr, "FAIL: Compile D\n");
        return 1;
    }
    if (tsfi_load_plugin("plugins/plugin_d.so", &logic_d) != 0) return 1;
    lau_update_logic(ws, &logic_d);
    ws->step_safety_epoch();
    printf("[TEST] Version after D: %d\n", *ws->version);

    // 7. Verification
    if (*ws->version == 900) {
        puts("[PASS] State persisted across hot-swap (100 -> 150 -> 300 -> 900).");
    } else {
        printf("[FAIL] State lost or incorrect logic. Expected 900, got %d\n", *ws->version);
        return 1;
    }

    // 8. Acoustic Manifold Persistence Test
    printf("[PERSIST] Testing Acoustic Manifold Cross-Invocation Retrieval...\n");
    void *manifold_orig = calloc(1, 512 * 1024);
    uint8_t root_orig[32], receipt_orig[32];
    tsfi_merkle_init();
    tsfi_merkle_reduce_11(root_orig, receipt_orig, manifold_orig, 1, 2026, NULL);
    
    char checkpoint[1024];
    char cwd[512];
    if (getcwd(cwd, sizeof(cwd))) {
        snprintf(checkpoint, sizeof(checkpoint), "%s/epoch_1.pos", cwd);
    } else {
        strncpy(checkpoint, "epoch_1.pos", sizeof(checkpoint));
    }
    printf("[PERSIST] Path: %s\n", checkpoint);
    if (tsfi_persist_manifold(checkpoint, manifold_orig, 512 * 1024) != 0) {
        printf("[FAIL] Failed to persist manifold to %s\n", checkpoint);
        exit(1);
    }
    
    void *manifold_restored = calloc(1, 512 * 1024);
    if (tsfi_restore_manifold(checkpoint, manifold_restored, 512 * 1024) != 0) {
        printf("[FAIL] Failed to restore manifold from %s\n", checkpoint);
        exit(1);
    }
    
    uint8_t root_restored[32], receipt_restored[32];
    tsfi_merkle_reduce_11(root_restored, receipt_restored, manifold_restored, 1, 2026, NULL);
    
    if (memcmp(root_orig, root_restored, 32) == 0) {
        printf("[PASS] Acoustic Proof of State Restored with Perfect Parity.\n");
    } else {
        printf("[FAIL] Manifold Divergence detected after restoration!\n");
        exit(1);
    }
    
    // unlink(checkpoint);
    free(manifold_orig);
    free(manifold_restored);
    tsfi_merkle_cleanup();

    extern void lau_free_all_active(void);
    lau_free_all_active();
    lau_report_memory_metrics();
    extern void lau_assert_zero_unsealed_leaks(const char *context, void *teardown_ptr);
    if (!getenv("TSFI_SKIP_LEAK_ASSERT")) {
        lau_assert_zero_unsealed_leaks("test", NULL);
    }
    return 0;
}