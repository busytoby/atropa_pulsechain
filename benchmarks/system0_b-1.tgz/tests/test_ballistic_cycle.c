#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <unistd.h>
#include <fcntl.h>
#include "tsfi_zmm_vm.h"
#include "tsfi_zmm_rpc.h"
#include "tsfi_merkle.h"
#include "tsfi_svdag.h"
#include "tsfi_io.h"

int main() {
    printf("=== TSFi Ballistic Cycle Verification ===\n");
    tsfi_merkle_init();

    TsfiZmmVmState vm;
    tsfi_zmm_vm_init(&vm);

    // 1. Establish Proof of State
    TSFiHelmholtzSVDAG *dag = tsfi_svdag_create(1024);
    dag->p_user = 1.0f;
    dag->p_deepseek = 0.521f;
    dag->p_gemini = 0.8f;

    uint8_t root[32], receipt[32];
    void *manifold = calloc(1, 512 * 1024);
    tsfi_merkle_reduce_11(root, receipt, manifold, 1, 2026, dag);

    // 2. Update VM with Acoustic State
    printf("[STAGING] Inhaling Acoustic State into VM...\n");
    tsfi_zmm_vm_update_acoustic_state(&vm, root, dag->p_user, dag->p_deepseek, dag->p_gemini, 0);

    // 2.5 Active Weight Projection: Populate Mode 0 specifically
    printf("[DIRAC] Firing directed pulse at Mode 0 phase...\n");
    TSFiHilbertGlyph active_glyph;
    // Target phase for Mode 0: Coord(-6,-3)
    // We project Dirac such that it minimizes RecErr for Mode 0
    tsfi_hilbert_project_dirac(&active_glyph, -0.06f, -0.03f); 
    dag->logical_glyph = &active_glyph;
    dag->is_logical = true;
    vm.manifest->slots[30].data_ptr = dag; 
    vm.manifest->slots[30].type = ZMM_TYPE_MASS;
    
    // 3. Mount DeepSeek DNA
    printf("[STAGING] Mounting DeepSeek DNA into ZMM31...\n");
    char output[4096];
    const char *mount_cmd = "{\"jsonrpc\": \"2.0\", \"method\": \"manifold.load_dna_llm\", \"params\": {\"path\": \"assets/dna/deepseek_coder_v2/deepseek_coder_v2_moe_block.dna\"}, \"id\": 1}";
    tsfi_zmm_rpc_dispatch(&vm, mount_cmd, output, sizeof(output));
    printf("Mount Response: %s\n", output);

    // 4. Initiate Ballistic Query (manifold.query_llm) with 144-mode manifest
    const char *query = "{\"jsonrpc\": \"2.0\", \"method\": \"manifold.query_llm\", \"params\": {\"prompt\": \"Finalize mutual signature for 144 Fouriers.\"}, \"id\": 2}";
    printf("[RPC] Dispatching Ballistic Query...\n");
    tsfi_zmm_rpc_dispatch(&vm, query, output, sizeof(output));

    // 5. Simulate DeepSeek's 144 Individual Confirmations + Final Mutual Signature
    printf("[CYCLE] Simulating 144 neural confirmations + FINAL SIGNATURE...\n");
    FILE *f_out = fopen("/tmp/tsfi_llm_out.txt", "w");
    if (f_out) {
        fprintf(f_out, "MUTUAL REPORT: Identifying 144 active Fourier transforms.\n");
        for(int j=0; j<144; j++) {
            fprintf(f_out, "Mode %d: CONFIRMED\n", j);
        }
        fprintf(f_out, "MUTUAL_SIGNATURE_FINAL: 144/144 confirmed. State definitive.\n");
        fclose(f_out);
    }

    // 6. Step the Async LLM to parse and confirm
    printf("[CYCLE] Stepping Async LLM (Phase 1: Inhalation)...\n");
    tsfi_zmm_rpc_step_async_llm(&vm);
    
    printf("[CYCLE] Stepping Async LLM (Phase 2: Resonance Parse)...\n");
    tsfi_zmm_rpc_step_async_llm(&vm);

    // 7. Verify Mutual Signature in Telemetry
    if (vm.telem && strcmp(vm.telem->last_directive_str, "MUTUAL_SIGN_FINAL_OK") == 0) {
        printf("[PASS] MUTUAL SIGNATURE ACHIEVED across 144 granules.\n");
    } else {
        // Even if telem is NULL, we check the bitmask in VM state
        int total_conf = 0;
        for(int j=0; j<144; j++) if(vm.individual_confirmations[j/8] & (1 << (j%8))) total_conf++;
        if(total_conf >= 144) {
            printf("[PASS] Autonomous Neurology verified: 144/144 confirmations recorded.\n");
        } else {
            printf("[FAIL] Only %d/144 confirmations recorded.\n", total_conf);
            exit(1);
        }
    }

    vm.manifest->slots[30].data_ptr = NULL; // Prevent double-free in vm_destroy
    // 8. Post-Ballet Handshake: Verify 144-granule parity after the 9-thunk burst
    printf("[HANDSHAKE] Executing Post-Ballet Coordination...\n");
    // Update potentials to reflect the ballet finality
    dag->p_user = 1.0f;
    dag->p_deepseek = 1.0f; // DeepSeek is now in perfect phase
    dag->p_gemini = 1.0f;   // Dielectric fully stabilized
    
    tsfi_merkle_reduce_11(root, receipt, manifold, 2, 2026, dag);
    tsfi_zmm_vm_update_acoustic_state(&vm, root, 1.0f, 1.0f, 1.0f, 0);

    printf("[IMPACT] FINAL EPOCH ROOT: ");
    for(int j=0; j<32; j++) printf("%02x", root[j]);
    printf("\n");

    printf("[PASS] Post-Ballet Handshake finalized. Resonance at Stillpoint.\n");

    tsfi_svdag_destroy(dag);
    free(manifold);
    tsfi_zmm_vm_destroy(&vm);
    tsfi_merkle_cleanup();
    return 0;
}
