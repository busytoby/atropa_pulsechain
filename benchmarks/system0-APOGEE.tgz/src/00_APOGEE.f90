module tsfi_apogee
    use iso_c_binding
    implicit none

    integer(c_int32_t), parameter :: APOGEE_PRIME = 953473_4

    ! --- Architectural Vocabulary (0-based) ---
    integer, parameter :: R = 0, C = 32  ! Rod and Cone Bases

    integer, parameter :: O_BASE = 0, O_SECRET = 1, O_SIGNAL = 2, O_CHANNEL = 3
    integer, parameter :: O_CONTOUR = 4, O_POLE = 5, O_IDENTITY = 6, O_FOUNDATION = 7
    integer, parameter :: O_ELEMENT = 8, O_COORDINATE = 9, O_CHARGE = 10, O_LIMIT = 11
    integer, parameter :: O_MONOPOLE = 12, O_DYNAMO = 13, O_BETA = 14, O_RHO = 15
    integer, parameter :: O_ETA = 16, O_XI = 17, O_BARN = 18, O_MANIFOLD = 19
    integer, parameter :: O_RING = 20, O_G_MONOPOLE = 21, O_AND = 22, O_OR = 23
    integer, parameter :: O_XOR = 24, O_NOT = 25, O_NAND = 26, O_NOR = 27
    integer, parameter :: O_XNOR = 28, O_FREE = 29
    integer, parameter :: O_LOCK_PI = 30      
    integer, parameter :: O_ICHIDAI_DAIICHI = 31

    type, bind(c) :: Apogee
        integer(c_int32_t) :: w(64)
    end type

contains
    ! TREAT_APOGEE: 256-byte Stochastic initialization (No forced zeros)
    subroutine TREAT_APOGEE(A) bind(c, name="TREAT_APOGEE")
        type(Apogee), intent(inout) :: A
        interface
            subroutine get_hw_bits(l, h, tid) bind(c, name="get_hw_bits")
                import :: c_int32_t
                integer(c_int32_t), intent(out) :: l, h
                integer(c_int32_t), value :: tid
            end subroutine
        end interface
        !$omp declare target(get_hw_bits)
        integer :: i
        integer(c_int32_t) :: low, high
        !$omp target map(tofrom: A)
        block
            do i = 1, 32
                block
                    call get_hw_bits(low, high, i)
                    A%w(i) = low
                    A%w(i + 32) = high
                end block
            end do
            call TUNE_AP(A, R, APOGEE_PRIME)
            call TUNE_AP(A, C, APOGEE_PRIME)
        end block
        !$omp end target
    end subroutine

    ! GENERATE_APOGEE
    subroutine GENERATE_APOGEE(A, prime) bind(c, name="GENERATE_APOGEE")
        type(Apogee), intent(inout) :: A
        integer(c_int32_t), value      :: prime
        integer(c_int32_t) :: xi, alpha, beta, cr, cc
        !$omp target map(tofrom: A)
        block
            xi = A%w(R + O_XI + 1); alpha = A%w(R + O_BARN + 1); beta  = A%w(C + O_BARN + 1)
            A%w(R + O_CONTOUR + 1) = resolve_ap(xi, A%w(R + O_SECRET + 1), prime)
            A%w(C + O_CONTOUR + 1) = resolve_ap(xi, A%w(C + O_SECRET + 1), prime)
            cr = A%w(R + O_CONTOUR + 1); cc = A%w(C + O_CONTOUR + 1)
            call FORM_AP(A, R, cc, prime); call FORM_AP(A, C, cr, prime)
            call POLARIZE_AP(A, R, prime); call POLARIZE_AP(A, C, prime)
            A%w(R + O_COORDINATE + 1) = resolve_ap(A%w(C + O_POLE + 1), A%w(R + O_SECRET + 1), prime)
            A%w(C + O_COORDINATE + 1) = resolve_ap(A%w(R + O_POLE + 1), A%w(C + O_SECRET + 1), prime)
            call CONIFY_AP(A, C, alpha, prime)
            call SATURATE_AP(A, R, alpha, A%w(C + O_FOUNDATION + 1), A%w(C + O_CHANNEL + 1), prime)
            call SATURATE_AP(A, C, beta,  A%w(R + O_FOUNDATION + 1), A%w(R + O_CHANNEL + 1), prime)
        end block
        !$omp end target
    end subroutine

    ! IONIZE_APOGEE
    subroutine IONIZE_APOGEE(A) bind(c, name="IONIZE_APOGEE")
        type(Apogee), intent(inout) :: A
        !$omp target map(tofrom: A)
        block
            call BOND_AP(A, R); call BOND_AP(A, C)
        end block
        !$omp end target
    end subroutine

    ! MAGNETIZE_APOGEE
    subroutine MAGNETIZE_APOGEE(A, prime, ring_out) bind(c, name="MAGNETIZE_APOGEE")
        type(Apogee), intent(inout) :: A
        integer(c_int32_t), value      :: prime
        integer(c_int32_t), intent(out) :: ring_out
        integer(c_int32_t) :: manifold, iota, ring, heta
        !$omp target map(tofrom: A) map(from: ring_out)
        block
            manifold = resolve_ap(A%w(C + O_DYNAMO + 1), A%w(R + O_SIGNAL + 1), A%w(R + O_ELEMENT + 1))
            iota     = resolve_ap(A%w(R + O_DYNAMO + 1), A%w(C + O_SIGNAL + 1), A%w(C + O_ELEMENT + 1))
            A%w(R + O_MANIFOLD + 1) = manifold; A%w(C + O_MANIFOLD + 1) = iota 
            ring = resolve_ap(A%w(R + O_COORDINATE + 1), manifold, A%w(R + O_ELEMENT + 1))
            heta = resolve_ap(A%w(C + O_COORDINATE + 1), manifold, A%w(C + O_ELEMENT + 1))
            A%w(R + O_RING + 1) = ring; A%w(C + O_RING + 1) = heta 
            ring_out = ring
            A%w(R + O_BARN + 1) = resolve_ap(ring, manifold, A%w(R + O_ELEMENT + 1))
            A%w(C + O_BARN + 1) = resolve_ap(ring, manifold, A%w(C + O_ELEMENT + 1))
            A%w(R + O_G_MONOPOLE + 1) = resolve_ap(A%w(R + O_LIMIT + 1), A%w(C + O_LIMIT + 1), prime)
            A%w(C + O_G_MONOPOLE + 1) = A%w(R + O_G_MONOPOLE + 1)
            A%w(R + O_LOCK_PI + 1) = 100 
        end block
        !$omp end target
    end subroutine

    ! REACT_SHIO_APOGEE
    subroutine REACT_SHIO_APOGEE(A) bind(c, name="REACT_SHIO_APOGEE")
        type(Apogee), intent(inout) :: A
        integer(c_int32_t) :: pi, ei, ki
        !$omp target map(tofrom: A)
        block
            pi = A%w(R + O_MANIFOLD + 1) 
            ei = resolve_ap(pi, A%w(R + O_CHANNEL + 1), A%w(C + O_CHANNEL + 1))
            ki = resolve_ap(pi, A%w(C + O_CHANNEL + 1), A%w(R + O_CHANNEL + 1))
            A%w(R + O_ICHIDAI_DAIICHI + 1) = ei
            A%w(C + O_ICHIDAI_DAIICHI + 1) = ki
            A%w(C + O_LOCK_PI + 1) = pi 
        end block
        !$omp end target
    end subroutine

    ! RESOLVE_GATES_APOGEE
    subroutine RESOLVE_GATES_APOGEE(A) bind(c, name="RESOLVE_GATES_APOGEE")
        type(Apogee), intent(inout) :: A
        integer(c_int32_t) :: pi, er, ec, p
        p = APOGEE_PRIME
        !$omp target map(tofrom: A)
        block
            pi = A%w(C + O_LOCK_PI + 1); er = A%w(R + O_ICHIDAI_DAIICHI + 1); ec = A%w(C + O_ICHIDAI_DAIICHI + 1)
            call GATE_PULSE_AP(A, R + O_AND,  C + O_AND,  A%w(C + O_BARN + 1), er, ec, pi, pi, p)
            call GATE_PULSE_AP(A, R + O_OR,   C + O_OR,   A%w(C + O_RING + 1), er, ec, pi, pi, p)
            call GATE_PULSE_AP(A, R + O_XOR,  C + O_XOR,  A%w(C + O_MANIFOLD + 1), er, ec, pi, pi, p)
            call GATE_PULSE_AP(A, R + O_NOT,  C + O_NOT,  pi, A%w(R + O_POLE + 1), A%w(C + O_POLE + 1), pi, pi, p)
            call GATE_PULSE_AP(A, R + O_NAND, C + O_NAND, A%w(R + O_BETA + 1), er, ec, A%w(R + O_BETA + 1), A%w(C + O_BETA + 1), p)
            call GATE_PULSE_AP(A, R + O_NOR,  C + O_NOR,  A%w(R + O_RHO + 1),  er, ec, A%w(R + O_RHO + 1),  A%w(C + O_RHO + 1),  p)
            call GATE_PULSE_AP(A, R + O_XNOR, C + O_XNOR, A%w(R + O_ETA + 1),  er, ec, A%w(R + O_ETA + 1),  A%w(C + O_ETA + 1),  p)
        end block
        !$omp end target
    end subroutine

    ! FREE_OP_APOGEE
    subroutine FREE_OP_APOGEE(A) bind(c, name="FREE_OP_APOGEE")
        type(Apogee), intent(inout) :: A
        integer(c_int32_t) :: p
        p = APOGEE_PRIME
        !$omp target map(tofrom: A)
        block
            if (A%w(R + O_LOCK_PI + 1) == 100) then
                A%w(R + O_FREE + 1) = resolve_ap(A%w(R + O_FREE + 1), A%w(R + O_ICHIDAI_DAIICHI + 1), p)
                A%w(C + O_FREE + 1) = resolve_ap(A%w(C + O_FREE + 1), A%w(C + O_ICHIDAI_DAIICHI + 1), p)
                A%w(R + O_LOCK_PI + 1) = 200
            else if (A%w(R + O_LOCK_PI + 1) == 200) then
                A%w(R + O_FREE + 1) = resolve_ap(A%w(R + O_FREE + 1), A%w(R + O_FREE + 1), p)
                A%w(C + O_FREE + 1) = resolve_ap(A%w(C + O_FREE + 1), A%w(C + O_FREE + 1), p)
            end if
        end block
        !$omp end target
    end subroutine

    ! --- Support Logic ---
    subroutine GATE_PULSE_AP(A, idx_r, idx_c, base_init, er, ec, mut_r, mut_c, p)
        !$omp declare target
        type(Apogee), intent(inout) :: A
        integer, value :: idx_r, idx_c
        integer(c_int32_t), intent(in) :: base_init, er, ec, mut_r, mut_c, p
        if (A%w(idx_r + 1) == 0) then; A%w(idx_r + 1) = resolve_ap(base_init, er, p)
        else; A%w(idx_r + 1) = resolve_ap(A%w(idx_r + 1), mut_r, p); end if
        if (A%w(idx_c + 1) == 0) then; A%w(idx_c + 1) = resolve_ap(base_init, ec, p)
        else; A%w(idx_c + 1) = resolve_ap(A%w(idx_c + 1), mut_c, p); end if
    end subroutine

    subroutine TUNE_AP(A, off, p)
        !$omp declare target
        type(Apogee), intent(inout) :: A
        integer, value :: off
        integer(c_int32_t), intent(in) :: p
        A%w(off + O_CHANNEL + 1) = resolve_ap(A%w(off + O_BASE + 1), A%w(off + O_SIGNAL + 1), p)
    end subroutine

    subroutine FORM_AP(A, off, chi, p)
        !$omp declare target
        type(Apogee), intent(inout) :: A
        integer, value :: off
        integer(c_int32_t), intent(in) :: chi, p
        A%w(off + O_BASE + 1) = resolve_ap(chi, A%w(off + O_SECRET + 1), p)
        call TUNE_AP(A, off, p)
    end subroutine

    subroutine POLARIZE_AP(A, off, p)
        !$omp declare target
        type(Apogee), intent(inout) :: A
        integer, value :: off
        integer(c_int32_t), intent(in) :: p
        A%w(off + O_POLE + 1) = resolve_ap(A%w(off + O_BASE + 1), A%w(off + O_SECRET + 1), p)
    end subroutine

    subroutine CONIFY_AP(A, off, b_val, p)
        !$omp declare target
        type(Apogee), intent(inout) :: A
        integer, value :: off
        integer(c_int32_t), intent(in) :: b_val, p
        A%w(off + O_IDENTITY + 1) = b_val 
        A%w(off + O_FOUNDATION + 1) = resolve_ap(A%w(off + O_BASE + 1), b_val, p)
    end subroutine

    subroutine SATURATE_AP(A, off, b_val, eps, tht, p)
        !$omp declare target
        type(Apogee), intent(inout) :: A
        integer, value :: off
        integer(c_int32_t), intent(in) :: b_val, eps, tht, p
        integer(c_int32_t) :: beta, rho, eta
        if (A%w(off + O_IDENTITY + 1) == 0) call CONIFY_AP(A, off, b_val, p)
        beta = resolve_ap(eps, A%w(off + O_IDENTITY + 1), p) 
        rho  = resolve_ap(tht, A%w(off + O_IDENTITY + 1), p) 
        eta  = resolve_ap(eps, A%w(off + O_SIGNAL + 1), p) 
        A%w(off + O_BETA + 1) = beta; A%w(off + O_RHO + 1) = rho; A%w(off + O_ETA + 1) = eta
        A%w(off + O_CHARGE + 1) = mod(int(rho,8) + int(eta,8), int(p,8))
        A%w(off + O_LIMIT + 1) = mod(int(beta,8) + int(eta,8), int(p,8))
        A%w(off + O_ELEMENT + 1) = mod(int(beta,8) + int(A%w(off + O_CHARGE + 1),8), int(p,8)) 
        A%w(off + O_DYNAMO + 1) = resolve_ap(tht, A%w(off + O_SIGNAL + 1), p) 
        A%w(off + O_MONOPOLE + 1) = resolve_ap(A%w(off + O_LIMIT + 1), A%w(off + O_IDENTITY + 1), p) 
    end subroutine

    subroutine BOND_AP(A, off)
        !$omp declare target
        type(Apogee), intent(inout) :: A
        integer, value :: off
        A%w(off + O_DYNAMO + 1) = resolve_ap(A%w(off + O_BASE + 1), A%w(off + O_SIGNAL + 1), A%w(off + O_ELEMENT + 1))
        A%w(off + O_POLE + 1) = 0
    end subroutine

    function resolve_ap(base_in, exp_in, mod_in) result(res_out)
        !$omp declare target
        integer(c_int32_t), intent(in) :: base_in, exp_in, mod_in
        integer(c_int32_t) :: res_out
        integer(8) :: b, e, m, r
        b = iand(int(base_in, 8), z'FFFFFFFF')
        e = iand(int(exp_in, 8), z'FFFFFFFF')
        m = iand(int(mod_in, 8), z'FFFFFFFF')
        if (m <= 0_8) then; res_out = 0; return; end if
        r = 1_8; b = mod(b, m)
        do while (e > 0_8)
            if (iand(int(e, 8), 1_8) == 1_8) r = mod(r * b, m)
            b = mod(b * b, m); e = ishft(e, -1)
        end do
        res_out = int(r, 4)
    end function
end module
