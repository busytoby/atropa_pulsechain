module tsfi_tune
    use iso_c_binding
    implicit none

    integer(c_int64_t), parameter :: MOTZKIN_PRIME = 953467954114363_8

    ! --- Architectural Vocabulary (0-based) ---
    integer, parameter :: R = 0, C = 32  ! Rod and Cone Bases

    integer, parameter :: O_BASE = 0, O_SECRET = 1, O_SIGNAL = 2, O_CHANNEL = 3
    integer, parameter :: O_CONTOUR = 4, O_POLE = 5, O_IDENTITY = 6, O_FOUNDATION = 7
    integer, parameter :: O_ELEMENT = 8, O_COORDINATE = 9, O_CHARGE = 10, O_LIMIT = 11
    integer, parameter :: O_MONOPOLE = 12, O_DYNAMO = 13, O_BETA = 14, O_RHO = 15
    integer, parameter :: O_ETA = 16, O_XI = 17, O_BARN = 18, O_MANIFOLD = 19
    integer, parameter :: O_RING = 20, O_G_MONOPOLE = 21, O_AND = 22, O_OR = 23
    integer, parameter :: O_XOR = 24, O_NOT = 25, O_NAND = 26, O_NOR = 27
    integer, parameter :: O_XNOR = 28, O_FREE = 29
    integer, parameter :: O_LOCK_PI = 30      ! Rod Lock / Cone Pi
    integer, parameter :: O_ICHIDAI_DAIICHI = 31

    type, bind(c) :: Dysnomia
        integer(c_int64_t) :: w(64)
    end type

contains
    ! TREAT: Initialization
    subroutine TREAT(D) bind(c, name="TREAT")
        type(Dysnomia), intent(inout) :: D
        interface
            subroutine get_hw_bits(l, h, tid) bind(c, name="get_hw_bits")
                import :: c_int32_t
                integer(c_int32_t), intent(out) :: l, h
                integer(c_int32_t), value :: tid
            end subroutine
        end interface
        !$omp declare target(get_hw_bits)
        integer :: i
        integer(c_int32_t) :: low, high
        !$omp target map(tofrom: D)
        block
            if (D%w(R + O_LOCK_PI + 1) == 0) then
                do i = 1, 64; D%w(i) = 0; end do
                do i = 1, 32
                    block
                        call get_hw_bits(low, high, i)
                        D%w(i) = transfer([low, high], D%w(i))
                        call get_hw_bits(low, high, i + 32)
                        D%w(i + 32) = transfer([low, high], D%w(i + 32))
                    end block
                end do
                ! Ensure sentinels are 0 for the first pulse
                D%w(R + O_LOCK_PI + 1) = 0
                D%w(C + O_LOCK_PI + 1) = 0
                D%w(R + O_ICHIDAI_DAIICHI + 1) = 0
                D%w(C + O_ICHIDAI_DAIICHI + 1) = 0
                
                call TUNE_OP(D, R, MOTZKIN_PRIME)
                call TUNE_OP(D, C, MOTZKIN_PRIME)
            end if
        end block
        !$omp end target
    end subroutine

    ! GENERATE: Field Resolution matching dysnomia.h
    subroutine GENERATE(D, prime) bind(c, name="GENERATE")
        type(Dysnomia), intent(inout) :: D
        integer(c_int64_t), value      :: prime
        integer(c_int64_t) :: xi, alpha, beta, cr, cc
        !$omp target map(tofrom: D)
        block
            if (D%w(R + O_LOCK_PI + 1) == 0) then
                xi = D%w(R + O_XI + 1)
                alpha = D%w(R + O_BARN + 1)
                beta  = D%w(C + O_BARN + 1)

                ! Avail
                D%w(R + O_CONTOUR + 1) = resolve_core(xi, D%w(R + O_SECRET + 1), prime)
                D%w(C + O_CONTOUR + 1) = resolve_core(xi, D%w(C + O_SECRET + 1), prime)
                cr = D%w(R + O_CONTOUR + 1); cc = D%w(C + O_CONTOUR + 1)

                ! Form
                call FORM_OP(D, R, cc, prime); call FORM_OP(D, C, cr, prime)
                
                ! Polarize
                call POLARIZE_OP(D, R, prime); call POLARIZE_OP(D, C, prime)

                ! Conjugate
                D%w(R + O_COORDINATE + 1) = resolve_core(D%w(C + O_POLE + 1), D%w(R + O_SECRET + 1), prime)
                D%w(C + O_COORDINATE + 1) = resolve_core(D%w(R + O_POLE + 1), D%w(C + O_SECRET + 1), prime)

                ! Conify & Saturate
                call CONIFY_OP(D, C, alpha, prime)
                call SATURATE_OP(D, R, alpha, D%w(C + O_FOUNDATION + 1), D%w(C + O_CHANNEL + 1), prime)
                call SATURATE_OP(D, C, beta,  D%w(R + O_FOUNDATION + 1), D%w(R + O_CHANNEL + 1), prime)
            end if
        end block
        !$omp end target
    end subroutine

    ! IONIZE
    subroutine IONIZE(D) bind(c, name="IONIZE")
        type(Dysnomia), intent(inout) :: D
        !$omp target map(tofrom: D)
        block
            if (D%w(R + O_LOCK_PI + 1) == 0) then
                call BOND_OP(D, R); call BOND_OP(D, C)
            end if
        end block
        !$omp end target
    end subroutine

    ! MAGNETIZE: Bijective foundation
    subroutine MAGNETIZE(D, prime, ring_out) bind(c, name="MAGNETIZE")
        type(Dysnomia), intent(inout) :: D
        integer(c_int64_t), value      :: prime
        integer(c_int64_t), intent(out) :: ring_out
        integer(c_int64_t) :: manifold, iota, ring, heta
        !$omp target map(tofrom: D) map(from: ring_out)
        block
            if (D%w(R + O_LOCK_PI + 1) == 0) then
                ! B->Manifold = Adduct(Rod, Cone->Dynamo)
                manifold = resolve_core(D%w(C + O_DYNAMO + 1), D%w(R + O_SIGNAL + 1), D%w(R + O_ELEMENT + 1))
                ! Iota = Adduct(Cone, Rod->Dynamo)
                iota     = resolve_core(D%w(R + O_DYNAMO + 1), D%w(C + O_SIGNAL + 1), D%w(C + O_ELEMENT + 1))
                
                D%w(R + O_MONOPOLE + 1) = manifold; D%w(C + O_MONOPOLE + 1) = iota 
                
                ! Ring = modPow(Rod->Coordinate, Manifold, Rod->Element)
                ring = resolve_core(D%w(R + O_COORDINATE + 1), manifold, D%w(R + O_ELEMENT + 1))
                ! Heta = modPow(Cone->Coordinate, Manifold, Cone->Element)
                heta = resolve_core(D%w(C + O_COORDINATE + 1), manifold, D%w(C + O_ELEMENT + 1))
                
                D%w(R + O_RING + 1) = ring; D%w(C + O_RING + 1) = heta 
                ring_out = ring

                ! Barn = modPow(Ring, Manifold, Rod->Element)
                D%w(R + O_BARN + 1) = resolve_core(ring, manifold, D%w(R + O_ELEMENT + 1))
                ! Zeta = modPow(Ring, Manifold, Cone->Element)
                D%w(C + O_BARN + 1) = resolve_core(ring, manifold, D%w(C + O_ELEMENT + 1))

                D%w(R + O_G_MONOPOLE + 1) = resolve_core(D%w(R + O_LIMIT + 1), D%w(C + O_LIMIT + 1), prime)
                D%w(C + O_G_MONOPOLE + 1) = D%w(R + O_G_MONOPOLE + 1)

                D%w(R + O_LOCK_PI + 1) = 100 
            end if
        end block
        !$omp end target
    end subroutine

    ! REACT_SHIO
    subroutine REACT_SHIO(D) bind(c, name="REACT_SHIO")
        type(Dysnomia), intent(inout) :: D
        integer(c_int64_t) :: pi, ei, ki
        !$omp target map(tofrom: D)
        block
            if (D%w(R + O_ICHIDAI_DAIICHI + 1) == 0) then
                pi = D%w(R + O_MANIFOLD + 1) 
                ei = resolve_core(pi, D%w(R + O_CHANNEL + 1), D%w(C + O_CHANNEL + 1))
                ki = resolve_core(pi, D%w(C + O_CHANNEL + 1), D%w(R + O_CHANNEL + 1))
                
                D%w(R + O_ICHIDAI_DAIICHI + 1) = ei
                D%w(C + O_ICHIDAI_DAIICHI + 1) = ki
                D%w(C + O_LOCK_PI + 1) = pi 
            end if
        end block
        !$omp end target
    end subroutine

    ! RESOLVE_GATES
    subroutine RESOLVE_GATES(D) bind(c, name="RESOLVE_GATES")
        type(Dysnomia), intent(inout) :: D
        integer(c_int64_t) :: pi, er, ec, p
        p = MOTZKIN_PRIME
        !$omp target map(tofrom: D)
        block
            pi = D%w(C + O_LOCK_PI + 1); er = D%w(R + O_ICHIDAI_DAIICHI + 1); ec = D%w(C + O_ICHIDAI_DAIICHI + 1)
            call GATE_PULSE(D, R + O_AND,  C + O_AND,  D%w(C + O_BARN + 1), er, ec, pi, pi, p)
            call GATE_PULSE(D, R + O_OR,   C + O_OR,   D%w(C + O_RING + 1), er, ec, pi, pi, p)
            call GATE_PULSE(D, R + O_XOR,  C + O_XOR,  D%w(C + O_MANIFOLD + 1), er, ec, pi, pi, p)
            call GATE_PULSE(D, R + O_NOT,  C + O_NOT,  pi, D%w(R + O_POLE + 1), D%w(C + O_POLE + 1), pi, pi, p)
            call GATE_PULSE(D, R + O_NAND, C + O_NAND, D%w(R + O_BETA + 1), er, ec, D%w(R + O_BETA + 1), D%w(C + O_BETA + 1), p)
            call GATE_PULSE(D, R + O_NOR,  C + O_NOR,  D%w(R + O_RHO + 1),  er, ec, D%w(R + O_RHO + 1),  D%w(C + O_RHO + 1),  p)
            call GATE_PULSE(D, R + O_XNOR, C + O_XNOR, D%w(R + O_ETA + 1),  er, ec, D%w(R + O_ETA + 1),  D%w(C + O_ETA + 1),  p)
        end block
        !$omp end target
    end subroutine

    ! FREE_OP
    subroutine FREE_OP(D) bind(c, name="FREE_OP")
        type(Dysnomia), intent(inout) :: D
        integer(c_int64_t) :: p
        p = MOTZKIN_PRIME
        !$omp target map(tofrom: D)
        block
            if (D%w(R + O_LOCK_PI + 1) == 100) then
                D%w(R + O_FREE + 1) = resolve_core(D%w(R + O_FREE + 1), D%w(R + O_ICHIDAI_DAIICHI + 1), p)
                D%w(C + O_FREE + 1) = resolve_core(D%w(C + O_FREE + 1), D%w(C + O_ICHIDAI_DAIICHI + 1), p)
                D%w(R + O_LOCK_PI + 1) = 200
            else if (D%w(R + O_LOCK_PI + 1) == 200) then
                D%w(R + O_FREE + 1) = resolve_core(D%w(R + O_FREE + 1), D%w(R + O_FREE + 1), p)
                D%w(C + O_FREE + 1) = resolve_core(D%w(C + O_FREE + 1), D%w(C + O_FREE + 1), p)
            end if
        end block
        !$omp end target
    end subroutine

    ! Internal Support Procedures
    subroutine GATE_PULSE(D, idx_r, idx_c, base_init, er, ec, mut_r, mut_c, p)
        !$omp declare target
        type(Dysnomia), intent(inout) :: D
        integer, value :: idx_r, idx_c
        integer(c_int64_t), intent(in) :: base_init, er, ec, mut_r, mut_c, p
        if (D%w(idx_r + 1) == 0) then; D%w(idx_r + 1) = resolve_core(base_init, er, p)
        else; D%w(idx_r + 1) = resolve_core(D%w(idx_r + 1), mut_r, p); end if
        if (D%w(idx_c + 1) == 0) then; D%w(idx_c + 1) = resolve_core(base_init, ec, p)
        else; D%w(idx_c + 1) = resolve_core(D%w(idx_c + 1), mut_c, p); end if
    end subroutine

    subroutine TUNE_OP(D, off, p)
        !$omp declare target
        type(Dysnomia), intent(inout) :: D
        integer, value :: off
        integer(c_int64_t), intent(in) :: p
        D%w(off + O_CHANNEL + 1) = resolve_core(D%w(off + O_BASE + 1), D%w(off + O_SIGNAL + 1), p)
    end subroutine

    subroutine FORM_OP(D, off, chi, p)
        !$omp declare target
        type(Dysnomia), intent(inout) :: D
        integer, value :: off
        integer(c_int64_t), intent(in) :: chi, p
        D%w(off + O_BASE + 1) = resolve_core(chi, D%w(off + O_SECRET + 1), p)
        call TUNE_OP(D, off, p)
    end subroutine

    subroutine POLARIZE_OP(D, off, p)
        !$omp declare target
        type(Dysnomia), intent(inout) :: D
        integer, value :: off
        integer(c_int64_t), intent(in) :: p
        D%w(off + O_POLE + 1) = resolve_core(D%w(off + O_BASE + 1), D%w(off + O_SECRET + 1), p)
    end subroutine

    subroutine CONIFY_OP(D, off, b_val, p)
        !$omp declare target
        type(Dysnomia), intent(inout) :: D
        integer, value :: off
        integer(c_int64_t), intent(in) :: b_val, p
        D%w(off + O_IDENTITY + 1) = b_val 
        D%w(off + O_FOUNDATION + 1) = resolve_core(D%w(off + O_BASE + 1), b_val, p)
    end subroutine

    subroutine SATURATE_OP(D, off, b_val, eps, tht, p)
        !$omp declare target
        type(Dysnomia), intent(inout) :: D
        integer, value :: off
        integer(c_int64_t), intent(in) :: b_val, eps, tht, p
        integer(c_int64_t) :: beta, rho, eta
        if (D%w(off + O_IDENTITY + 1) == 0) call CONIFY_OP(D, off, b_val, p)
        beta = resolve_core(eps, D%w(off + O_IDENTITY + 1), p) 
        rho  = resolve_core(tht, D%w(off + O_IDENTITY + 1), p) 
        eta  = resolve_core(eps, D%w(off + O_SIGNAL + 1), p) 
        D%w(off + O_BETA + 1) = beta; D%w(off + O_RHO + 1) = rho; D%w(off + O_ETA + 1) = eta
        D%w(off + O_CHARGE + 1) = rho + eta 
        D%w(off + O_LIMIT + 1) = beta + eta 
        D%w(off + O_ELEMENT + 1) = beta + D%w(off + O_CHARGE + 1) 
        D%w(off + O_DYNAMO + 1) = resolve_core(tht, D%w(off + O_SIGNAL + 1), p) 
        D%w(off + O_MONOPOLE + 1) = resolve_core(D%w(off + O_LIMIT + 1), D%w(off + O_IDENTITY + 1), p) 
    end subroutine

    subroutine BOND_OP(D, off)
        !$omp declare target
        type(Dysnomia), intent(inout) :: D
        integer, value :: off
        D%w(off + O_DYNAMO + 1) = resolve_core(D%w(off + O_BASE + 1), D%w(off + O_SIGNAL + 1), D%w(off + O_ELEMENT + 1))
        D%w(off + O_POLE + 1) = 0
    end subroutine

    function resolve_core(base_in, exp_in, mod_in) result(res_out)
        !$omp declare target
        integer(c_int64_t), intent(in) :: base_in, exp_in, mod_in
        integer(c_int64_t) :: res_out
        integer(16) :: b, e, m, r
        b = iand(int(base_in, 16), z'FFFFFFFFFFFFFFFF')
        e = iand(int(exp_in, 16), z'FFFFFFFFFFFFFFFF')
        m = iand(int(mod_in, 16), z'FFFFFFFFFFFFFFFF')
        if (m <= 0_16) then; res_out = 0; return; end if
        r = 1_16; b = mod(b, m)
        do while (e > 0_16)
            if (iand(int(e, 8), 1_8) == 1_8) r = mod(r * b, m)
            b = mod(b * b, m); e = ishft(e, -1)
        end do
        res_out = int(r, 8)
    end function

    subroutine PULSE_MUTABLE(D, index, val) bind(c, name="PULSE_MUTABLE")
        type(Dysnomia), intent(inout) :: D
        integer(c_int32_t), value :: index
        integer(c_int64_t), value :: val
        !$omp target map(tofrom: D)
        block
            if (index >= 22 .and. index <= 29 .or. index >= 54 .and. index <= 61) then
                D%w(index + 1) = val
            end if
        end block
        !$omp end target
    end subroutine
end module
