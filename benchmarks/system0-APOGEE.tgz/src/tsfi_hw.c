#include <stdint.h>

#pragma omp declare target
void get_hw_bits(uint32_t *l, uint32_t *h, uint32_t tid) {
#if defined(__AMDGCN__)
    // GFX1201 O(1) Hardware Extraction
    uint32_t se = __builtin_amdgcn_s_sendmsg_rtn(0x87); 
    uint64_t t = __builtin_readcyclecounter();
    
    uint64_t x = t ^ ((uint64_t)se << 32) ^ ((uint64_t)tid << 48);
    x *= 0xd6e8feb86659fd93ull; 
    
    *l = (uint32_t)x;
    *h = (uint32_t)(x >> 32);
#else
    *l = 0; *h = 0;
#endif
}
#pragma omp end declare target
