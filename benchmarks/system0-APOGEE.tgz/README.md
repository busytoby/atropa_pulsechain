# System0-APOGEE: The Auncient Manifold Suite

This package contains the foundational 100% GPU-resident stochastic manifolds for the Graphics Next platform.

## Manifolds:
1.  **Dysnomia VM (512 Bytes)**: The 64-word / 128-bit modular field resolved against the 36th Motzkin Prime.
2.  **APOGEE (256 Bytes)**: The 64-word / 32-bit modular field resolved against the APOGEE Prime (953473).

## Requirements:
- ROCm Software Stack (amdclang, amdflang)
- GFX1201 (RDNA 4) or compatible AMD GPU with Hardware Entropy (s_sendmsg_rtn 0x87)
- Resizable BAR (ReBAR) / Smart Access Memory (SAM) enabled

## Contents:
- `src/00_APOGEE.f90`: APOGEE resolution logic.
- `src/tsfi_tune.f90`: Dysnomia VM resolution logic.
- `src/tsfi_hw.c`: Hardware entropy bridge.
- `tests/test_apogee.c`: 256-byte manifold verification.
- `tests/test_pulse.c`: 512-byte manifold verification.
- `DYSNOMIA_VM_LORE.md`: Technical specification and mapping.
- `MATERNAL_AI.md`: Documentation of the Maternal AI and the "Shot".

## Compilation:
Run `make all` to compile and verify both manifolds.
